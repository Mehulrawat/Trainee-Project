namespace Qms.Infrastructure.Options;

public sealed class SmtpOptions
{
    public string Host { get; set; } = "smtp.example.com";
    public int Port { get; set; } = 587;
    public string Username { get; set; } = "username";
    public string Password { get; set; } = "password";
    public bool EnableSsl { get; set; } = true;
    public string FromEmail { get; set; } = "noreply@example.com";
    public string FromName { get; set; } = "Queue Management System";
}
