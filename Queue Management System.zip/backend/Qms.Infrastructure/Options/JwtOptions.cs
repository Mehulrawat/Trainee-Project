namespace Qms.Infrastructure.Options;

public sealed class JwtOptions
{
    public string Issuer { get; set; } = "qms";
    public string Audience { get; set; } = "qms-web";
    public string SigningKey { get; set; } = "CHANGE_ME_USE_LONG_RANDOM_SECRET";
    public int AccessTokenMinutes { get; set; } = 120;
}
