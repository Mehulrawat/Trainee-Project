using Microsoft.AspNetCore.Identity;
using Qms.Domain.Entities;

namespace Qms.Infrastructure.Security;

public static class PasswordHasherAdapter
{
    private static readonly PasswordHasher<AppUser> Hasher = new();

    public static string HashPassword(AppUser user, string password) => Hasher.HashPassword(user, password);

    public static bool VerifyHashedPassword(AppUser user, string hashedPassword, string providedPassword)
    {
        var result = Hasher.VerifyHashedPassword(user, hashedPassword, providedPassword);
        return result is PasswordVerificationResult.Success or PasswordVerificationResult.SuccessRehashNeeded;
    }
}
