using Microsoft.EntityFrameworkCore;
using Qms.Application.Abstractions;
using Qms.Application.Models;
using Qms.Domain.Entities;
using Qms.Domain.Enums;

namespace Qms.Infrastructure.Services;

public sealed class TokenService : ITokenService
{
    private readonly IAppDbContext _db;
    private readonly INotificationService _notifications;

    public TokenService(IAppDbContext db, INotificationService notifications)
    {
        _db = db;
        _notifications = notifications;
    }

    public async Task<TokenDto> IssueTokenAsync(IssueTokenRequest request, Guid? performedByUserId, CancellationToken ct = default)
    {
        var service = await _db.ServiceTypes.FirstAsync(s => s.Id == request.ServiceTypeId && s.IsActive, ct);

        // simple daily sequence: count today + 1 (acceptable for baseline; can be replaced with SQL sequence)
        var today = DateTime.UtcNow.Date;
        var nextSeq = await _db.Tokens
            .Where(t => t.BranchId == request.BranchId && t.ServiceTypeId == request.ServiceTypeId && t.IssuedAtUtc >= today)
            .CountAsync(ct) + 1;

        var tokenNo = $"{service.Prefix}-{nextSeq:000}";

        var token = new Token
        {
            BranchId = request.BranchId,
            ServiceTypeId = request.ServiceTypeId,
            SequenceNo = nextSeq,
            TokenNo = tokenNo,
            Status = TokenStatus.Waiting,
            CustomerEmail = request.CustomerEmail
        };

        _db.Tokens.Add(token);
        _db.TokenAuditLogs.Add(new TokenAuditLog
        {
            TokenId = token.Id,
            FromStatus = TokenStatus.Waiting,
            ToStatus = TokenStatus.Waiting,
            PerformedByUserId = performedByUserId,
            Note = "Token issued"
        });

        await _db.SaveChangesAsync(ct);

        await _notifications.EnqueueNotificationsAsync(NotificationEventType.TokenIssued, token, ct);

        return await ToDtoAsync(token.Id, ct);
    }

    public async Task<TokenDto?> GetTokenAsync(Guid tokenId, CancellationToken ct = default)
    {
        var token = await _db.Tokens
            .Include(t => t.ServiceType)
            .FirstOrDefaultAsync(t => t.Id == tokenId, ct);
        return token is null ? null : Map(token);
    }

    public async Task<IReadOnlyList<TokenDto>> GetQueueStatusAsync(Guid branchId, Guid serviceTypeId, CancellationToken ct = default)
    {
        var items = await _db.Tokens
            .Include(t => t.ServiceType)
            .Where(t => t.BranchId == branchId && t.ServiceTypeId == serviceTypeId && t.Status != TokenStatus.Served && t.Status != TokenStatus.Cancelled)
            .OrderBy(t => t.IssuedAtUtc)
            .Take(200)
            .ToListAsync(ct);

        return items.Select(Map).ToList();
    }

    public async Task<TokenDto?> CallNextAsync(CallNextRequest request, Guid performedByUserId, CancellationToken ct = default)
    {
        // Enforce: prevent concurrent calls + only one active serving token per counter
        // Approach: transaction + check existing serving token for counter, then pick earliest waiting token among assigned services.
        using var tx = await (_db as DbContext)!.Database.BeginTransactionAsync(ct);

        var counter = await _db.Counters.FirstAsync(c => c.Id == request.CounterId && c.BranchId == request.BranchId && c.IsActive, ct);

        var alreadyServing = await _db.Tokens.AnyAsync(t => t.CurrentCounterId == counter.Id && t.Status == TokenStatus.Serving, ct);
        if (alreadyServing)
        {
            await tx.RollbackAsync(ct);
            return null;
        }

        var allowedServiceIds = await _db.CounterServiceTypes
            .Where(x => x.CounterId == counter.Id)
            .Select(x => x.ServiceTypeId)
            .ToListAsync(ct);

        if (allowedServiceIds.Count == 0)
        {
            await tx.RollbackAsync(ct);
            return null;
        }

        // pick earliest Waiting across allowed services
        var token = await _db.Tokens
            .Where(t => t.BranchId == request.BranchId && allowedServiceIds.Contains(t.ServiceTypeId) && t.Status == TokenStatus.Waiting)
            .OrderBy(t => t.IssuedAtUtc)
            .FirstOrDefaultAsync(ct);

        if (token is null)
        {
            await tx.RollbackAsync(ct);
            return null;
        }

        var from = token.Status;
        token.Status = TokenStatus.Serving;
        token.CalledAtUtc = DateTime.UtcNow;
        token.CurrentCounterId = counter.Id;

        _db.TokenAuditLogs.Add(new TokenAuditLog
        {
            TokenId = token.Id,
            FromStatus = from,
            ToStatus = token.Status,
            PerformedByUserId = performedByUserId,
            Note = $"Called to counter {counter.Name}"
        });

        await _db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);

        await _notifications.EnqueueNotificationsAsync(NotificationEventType.TokenCalled, token, ct);

        return await ToDtoAsync(token.Id, ct);
    }

    public async Task<TokenDto> SkipAsync(Guid tokenId, Guid performedByUserId, CancellationToken ct = default)
    {
        var token = await _db.Tokens.FirstAsync(t => t.Id == tokenId, ct);
        var from = token.Status;

        if (token.Status != TokenStatus.Serving && token.Status != TokenStatus.Waiting)
            throw new InvalidOperationException("Only Waiting/Serving tokens can be skipped.");

        token.Status = TokenStatus.Skipped;
        token.CurrentCounterId = token.CurrentCounterId; // keep for audit
        _db.TokenAuditLogs.Add(new TokenAuditLog
        {
            TokenId = token.Id,
            FromStatus = from,
            ToStatus = token.Status,
            PerformedByUserId = performedByUserId,
            Note = "Skipped"
        });

        await _db.SaveChangesAsync(ct);
        await _notifications.EnqueueNotificationsAsync(NotificationEventType.TokenSkipped, token, ct);

        return await ToDtoAsync(token.Id, ct);
    }

    public async Task<TokenDto> ServeAsync(Guid tokenId, Guid performedByUserId, CancellationToken ct = default)
    {
        var token = await _db.Tokens.FirstAsync(t => t.Id == tokenId, ct);
        var from = token.Status;

        if (token.Status != TokenStatus.Serving)
            throw new InvalidOperationException("Only Serving tokens can be marked Served.");

        token.Status = TokenStatus.Served;
        token.ServedAtUtc = DateTime.UtcNow;

        _db.TokenAuditLogs.Add(new TokenAuditLog
        {
            TokenId = token.Id,
            FromStatus = from,
            ToStatus = token.Status,
            PerformedByUserId = performedByUserId,
            Note = "Served"
        });

        await _db.SaveChangesAsync(ct);
        await _notifications.EnqueueNotificationsAsync(NotificationEventType.TokenServed, token, ct);

        return await ToDtoAsync(token.Id, ct);
    }

    public async Task<TokenDto> CancelAsync(Guid tokenId, Guid? performedByUserId, CancellationToken ct = default)
    {
        var token = await _db.Tokens.FirstAsync(t => t.Id == tokenId, ct);
        var from = token.Status;

        if (token.Status == TokenStatus.Served)
            throw new InvalidOperationException("Served tokens cannot be cancelled.");

        token.Status = TokenStatus.Cancelled;
        token.CancelledAtUtc = DateTime.UtcNow;

        _db.TokenAuditLogs.Add(new TokenAuditLog
        {
            TokenId = token.Id,
            FromStatus = from,
            ToStatus = token.Status,
            PerformedByUserId = performedByUserId,
            Note = "Cancelled"
        });

        await _db.SaveChangesAsync(ct);
        await _notifications.EnqueueNotificationsAsync(NotificationEventType.TokenCancelled, token, ct);

        return await ToDtoAsync(token.Id, ct);
    }

    public async Task ResetQueueAsync(Guid branchId, Guid performedByUserId, CancellationToken ct = default)
    {
        // Mark all Waiting/Serving/Skipped tokens as Cancelled (soft reset baseline)
        var tokens = await _db.Tokens
            .Where(t => t.BranchId == branchId && t.Status != TokenStatus.Served && t.Status != TokenStatus.Cancelled)
            .ToListAsync(ct);

        foreach (var t in tokens)
        {
            var from = t.Status;
            t.Status = TokenStatus.Cancelled;
            t.CancelledAtUtc = DateTime.UtcNow;

            _db.TokenAuditLogs.Add(new TokenAuditLog
            {
                TokenId = t.Id,
                FromStatus = from,
                ToStatus = t.Status,
                PerformedByUserId = performedByUserId,
                Note = "Queue reset"
            });
        }

        await _db.SaveChangesAsync(ct);
    }

    private async Task<TokenDto> ToDtoAsync(Guid tokenId, CancellationToken ct)
    {
        var token = await _db.Tokens.Include(t => t.ServiceType).FirstAsync(t => t.Id == tokenId, ct);
        return Map(token);
    }

    private static TokenDto Map(Token t) => new()
    {
        Id = t.Id,
        BranchId = t.BranchId,
        ServiceTypeId = t.ServiceTypeId,
        ServiceTypeName = t.ServiceType?.Name ?? "",
        TokenNo = t.TokenNo,
        Status = t.Status,
        IssuedAtUtc = t.IssuedAtUtc,
        CalledAtUtc = t.CalledAtUtc,
        ServedAtUtc = t.ServedAtUtc,
        CurrentCounterId = t.CurrentCounterId,
        CustomerEmail = t.CustomerEmail
    };
}
