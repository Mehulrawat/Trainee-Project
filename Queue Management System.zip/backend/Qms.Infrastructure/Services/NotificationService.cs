using Microsoft.EntityFrameworkCore;
using Qms.Application.Abstractions;
using Qms.Domain.Entities;
using Qms.Domain.Enums;

namespace Qms.Infrastructure.Services;

public sealed class NotificationService : INotificationService
{
    private readonly IAppDbContext _db;

    public NotificationService(IAppDbContext db) => _db = db;

    public async Task EnqueueNotificationsAsync(NotificationEventType eventType, Token token, CancellationToken ct = default)
    {
        var rules = await _db.NotificationRules
            .Include(r => r.EmailTemplate)
            .Where(r => r.IsEnabled && r.EventType == eventType)
            .ToListAsync(ct);

        foreach (var rule in rules)
        {
            var recipients = new List<string>();

            if (rule.SendToCustomer && !string.IsNullOrWhiteSpace(token.CustomerEmail))
                recipients.Add(token.CustomerEmail!);

            if (rule.SendToStaff && !string.IsNullOrWhiteSpace(rule.StaffEmailsCsv))
            {
                recipients.AddRange(
                    rule.StaffEmailsCsv
                        .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                        .Where(e => e.Contains('@'))
                );
            }

            if (recipients.Count == 0) continue;

            foreach (var to in recipients.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                var subject = Render(rule.EmailTemplate.Subject, token);
                var body = Render(rule.EmailTemplate.Body, token);

                _db.EmailDeliveryLogs.Add(new EmailDeliveryLog
                {
                    TokenId = token.Id,
                    EventType = eventType,
                    RecipientEmail = to,
                    Subject = subject,
                    Body = body,
                    Status = EmailDeliveryStatus.Pending,
                    AttemptCount = 0,
                    NextRetryAtUtc = DateTime.UtcNow
                });
            }
        }

        await _db.SaveChangesAsync(ct);
    }

    private static string Render(string template, Token token)
    {
        // Very small placeholder system; can be swapped for Razor/Fluid later.
        return template
            .Replace("{{TokenNo}}", token.TokenNo)
            .Replace("{{Status}}", token.Status.ToString())
            .Replace("{{ServiceTypeId}}", token.ServiceTypeId.ToString())
            .Replace("{{BranchId}}", token.BranchId.ToString());
    }
}
