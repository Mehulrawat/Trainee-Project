using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Qms.Application.Abstractions;
using Qms.Domain.Enums;

namespace Qms.Infrastructure.Services;

public sealed class EmailRetryWorker : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<EmailRetryWorker> _logger;

    public EmailRetryWorker(IServiceScopeFactory scopeFactory, ILogger<EmailRetryWorker> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<IAppDbContext>();
                var sender = scope.ServiceProvider.GetRequiredService<IEmailSender>();

                var now = DateTime.UtcNow;

                var pending = await db.EmailDeliveryLogs
                    .Where(x => x.Status == EmailDeliveryStatus.Pending && (x.NextRetryAtUtc == null || x.NextRetryAtUtc <= now))
                    .OrderBy(x => x.CreatedAtUtc)
                    .Take(25)
                    .ToListAsync(stoppingToken);

                foreach (var item in pending)
                {
                    item.AttemptCount++;
                    try
                    {
                        await sender.SendAsync(item.RecipientEmail, item.Subject, item.Body, stoppingToken);
                        item.Status = EmailDeliveryStatus.Sent;
                        item.LastError = null;
                        item.NextRetryAtUtc = null;
                    }
                    catch (Exception ex)
                    {
                        item.Status = EmailDeliveryStatus.Pending; // keep pending for retry
                        item.LastError = ex.Message;
                        // exponential backoff: 1m, 2m, 4m, 8m...
                        var minutes = Math.Min(60, (int)Math.Pow(2, Math.Min(6, item.AttemptCount)));
                        item.NextRetryAtUtc = DateTime.UtcNow.AddMinutes(minutes);
                        if (item.AttemptCount >= 8)
                        {
                            item.Status = EmailDeliveryStatus.Failed;
                        }
                    }
                }

                await db.SaveChangesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "EmailRetryWorker loop failed");
            }

            await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
        }
    }
}
