using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using Qms.Application.Abstractions;
using Qms.Infrastructure.Options;

namespace Qms.Infrastructure.Services;

public sealed class SmtpEmailSender : IEmailSender
{
    private readonly SmtpOptions _options;

    public SmtpEmailSender(IOptions<SmtpOptions> options) => _options = options.Value;

    public async Task SendAsync(string to, string subject, string body, CancellationToken ct = default)
    {
        using var client = new SmtpClient(_options.Host, _options.Port)
        {
            EnableSsl = _options.EnableSsl,
            Credentials = new NetworkCredential(_options.Username, _options.Password)
        };

        using var message = new MailMessage
        {
            From = new MailAddress(_options.FromEmail, _options.FromName),
            Subject = subject,
            Body = body,
            IsBodyHtml = false
        };
        message.To.Add(to);

        // SmtpClient is not truly async internally, but SendMailAsync exists and is good enough for a baseline.
        await client.SendMailAsync(message, ct);
    }
}
