using Microsoft.EntityFrameworkCore;
using Qms.Application.Abstractions;
using Qms.Domain.Entities;

namespace Qms.Infrastructure.Persistence;

public sealed class QmsDbContext : DbContext, IAppDbContext
{
    public QmsDbContext(DbContextOptions<QmsDbContext> options) : base(options) { }

    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<ServiceType> ServiceTypes => Set<ServiceType>();
    public DbSet<Counter> Counters => Set<Counter>();
    public DbSet<CounterServiceType> CounterServiceTypes => Set<CounterServiceType>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Token> Tokens => Set<Token>();
    public DbSet<TokenAuditLog> TokenAuditLogs => Set<TokenAuditLog>();
    public DbSet<EmailTemplate> EmailTemplates => Set<EmailTemplate>();
    public DbSet<NotificationRule> NotificationRules => Set<NotificationRule>();
    public DbSet<EmailDeliveryLog> EmailDeliveryLogs => Set<EmailDeliveryLog>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AppUser>()
            .HasIndex(x => x.Email)
            .IsUnique();

        modelBuilder.Entity<Branch>()
            .HasIndex(x => x.Code)
            .IsUnique();

        modelBuilder.Entity<ServiceType>()
            .HasIndex(x => new { x.BranchId, x.Name })
            .IsUnique();

        modelBuilder.Entity<Counter>()
            .HasIndex(x => new { x.BranchId, x.Name })
            .IsUnique();

        modelBuilder.Entity<CounterServiceType>()
            .HasKey(x => new { x.CounterId, x.ServiceTypeId });

        modelBuilder.Entity<Token>()
            .Property(x => x.RowVersion)
            .IsRowVersion();

        base.OnModelCreating(modelBuilder);
    }
}
