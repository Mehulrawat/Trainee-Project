using Microsoft.EntityFrameworkCore;
using Qms.Domain.Entities;
using Qms.Domain.Enums;
using Qms.Infrastructure.Security;

namespace Qms.Infrastructure.Seed;

public static class DbSeeder
{
    public static async Task SeedAsync(DbContext db, CancellationToken ct = default)
    {
        // Create default branch
        var branch = await db.Set<Branch>().FirstOrDefaultAsync(b => b.Code == "MAIN", ct);
        if (branch is null)
        {
            branch = new Branch { Name = "Main Branch", Code = "MAIN" };
            db.Add(branch);
            await db.SaveChangesAsync(ct);
        }

        // Default services
        async Task EnsureService(string name, string prefix)
        {
            if (!await db.Set<ServiceType>().AnyAsync(s => s.BranchId == branch.Id && s.Name == name, ct))
            {
                db.Add(new ServiceType { BranchId = branch.Id, Name = name, Prefix = prefix, IsActive = true });
            }
        }

        await EnsureService("General", "A");
        await EnsureService("Payments", "B");
        await EnsureService("Support", "C");

        // Default counters
        async Task EnsureCounter(string name)
        {
            if (!await db.Set<Counter>().AnyAsync(c => c.BranchId == branch.Id && c.Name == name, ct))
            {
                db.Add(new Counter { BranchId = branch.Id, Name = name, IsActive = true });
            }
        }

        await EnsureCounter("Counter 1");
        await EnsureCounter("Counter 2");

        await db.SaveChangesAsync(ct);

        // Assign services to counters (Counter 1 => General, Payments; Counter 2 => Support)
        var services = await db.Set<ServiceType>().Where(s => s.BranchId == branch.Id).ToListAsync(ct);
        var c1 = await db.Set<Counter>().FirstAsync(c => c.BranchId == branch.Id && c.Name == "Counter 1", ct);
        var c2 = await db.Set<Counter>().FirstAsync(c => c.BranchId == branch.Id && c.Name == "Counter 2", ct);

        void Link(Counter c, ServiceType s)
        {
            if (!db.Set<CounterServiceType>().Any(x => x.CounterId == c.Id && x.ServiceTypeId == s.Id))
                db.Add(new CounterServiceType { CounterId = c.Id, ServiceTypeId = s.Id });
        }

        var general = services.First(s => s.Name == "General");
        var payments = services.First(s => s.Name == "Payments");
        var support = services.First(s => s.Name == "Support");

        Link(c1, general);
        Link(c1, payments);
        Link(c2, support);

        // Email templates + rules
        if (!await db.Set<EmailTemplate>().AnyAsync(ct))
        {
            var tplIssued = new EmailTemplate
            {
                Name = "Token Issued",
                Subject = "Your token {{TokenNo}} has been issued",
                Body = "Token {{TokenNo}} has been issued. Status: {{Status}}."
            };
            var tplCalled = new EmailTemplate
            {
                Name = "Token Called",
                Subject = "Your token {{TokenNo}} is called",
                Body = "Token {{TokenNo}} is now being served. Status: {{Status}}."
            };
            db.AddRange(tplIssued, tplCalled);
            await db.SaveChangesAsync(ct);

            db.Add(new NotificationRule
            {
                EventType = NotificationEventType.TokenIssued,
                IsEnabled = true,
                SendToCustomer = true,
                SendToStaff = false,
                EmailTemplateId = tplIssued.Id
            });

            db.Add(new NotificationRule
            {
                EventType = NotificationEventType.TokenCalled,
                IsEnabled = true,
                SendToCustomer = true,
                SendToStaff = false,
                EmailTemplateId = tplCalled.Id
            });

            await db.SaveChangesAsync(ct);
        }

        // Users: Admin + Staff + demo customer
        async Task EnsureUser(string email, string password, AppRole role)
        {
            var set = db.Set<AppUser>();
            var existing = await set.FirstOrDefaultAsync(u => u.Email == email, ct);
            if (existing is null)
            {
                var u = new AppUser { Email = email, Role = role, IsActive = true, BranchId = branch.Id };
                u.PasswordHash = PasswordHasherAdapter.HashPassword(u, password);
                db.Add(u);
                await db.SaveChangesAsync(ct);
            }
        }

        await EnsureUser("admin@qms.local", "Admin123$!", AppRole.Admin);
        await EnsureUser("staff@qms.local", "Staff123$!", AppRole.Staff);
        await EnsureUser("customer@qms.local", "Customer123$!", AppRole.Customer);
    }
}
