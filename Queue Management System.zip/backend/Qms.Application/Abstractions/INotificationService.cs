using Qms.Domain.Enums;
using Qms.Domain.Entities;

namespace Qms.Application.Abstractions;

public interface INotificationService
{
    Task EnqueueNotificationsAsync(NotificationEventType eventType, Token token, CancellationToken ct = default);
}
