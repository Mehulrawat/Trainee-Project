using Microsoft.EntityFrameworkCore;
using Qms.Domain.Entities;

namespace Qms.Application.Abstractions;

public interface IAppDbContext
{
    DbSet<Branch> Branches { get; }
    DbSet<ServiceType> ServiceTypes { get; }
    DbSet<Counter> Counters { get; }
    DbSet<CounterServiceType> CounterServiceTypes { get; }
    DbSet<AppUser> Users { get; }
    DbSet<Token> Tokens { get; }
    DbSet<TokenAuditLog> TokenAuditLogs { get; }
    DbSet<EmailTemplate> EmailTemplates { get; }
    DbSet<NotificationRule> NotificationRules { get; }
    DbSet<EmailDeliveryLog> EmailDeliveryLogs { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
