using Qms.Application.Models;

namespace Qms.Application.Abstractions;

public interface ITokenService
{
    Task<TokenDto> IssueTokenAsync(IssueTokenRequest request, Guid? performedByUserId, CancellationToken ct = default);
    Task<TokenDto?> GetTokenAsync(Guid tokenId, CancellationToken ct = default);
    Task<IReadOnlyList<TokenDto>> GetQueueStatusAsync(Guid branchId, Guid serviceTypeId, CancellationToken ct = default);

    Task<TokenDto?> CallNextAsync(CallNextRequest request, Guid performedByUserId, CancellationToken ct = default);
    Task<TokenDto> SkipAsync(Guid tokenId, Guid performedByUserId, CancellationToken ct = default);
    Task<TokenDto> ServeAsync(Guid tokenId, Guid performedByUserId, CancellationToken ct = default);
    Task<TokenDto> CancelAsync(Guid tokenId, Guid? performedByUserId, CancellationToken ct = default);

    Task ResetQueueAsync(Guid branchId, Guid performedByUserId, CancellationToken ct = default);
}
