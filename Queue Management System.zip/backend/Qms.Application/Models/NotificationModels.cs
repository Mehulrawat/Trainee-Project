using Qms.Domain.Enums;

namespace Qms.Application.Models;

public sealed record CreateEmailTemplateRequest(string Name, string Subject, string Body);
public sealed record UpdateEmailTemplateRequest(string Name, string Subject, string Body);

public sealed record CreateNotificationRuleRequest(
    NotificationEventType EventType,
    bool IsEnabled,
    bool SendToCustomer,
    bool SendToStaff,
    string? StaffEmailsCsv,
    Guid EmailTemplateId
);

public sealed record UpdateNotificationRuleRequest(
    NotificationEventType EventType,
    bool IsEnabled,
    bool SendToCustomer,
    bool SendToStaff,
    string? StaffEmailsCsv,
    Guid EmailTemplateId
);
