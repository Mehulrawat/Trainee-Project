using Qms.Domain.Enums;

namespace Qms.Application.Models;

public sealed record IssueTokenRequest(Guid BranchId, Guid ServiceTypeId, string? CustomerEmail);

public sealed record CallNextRequest(Guid BranchId, Guid CounterId);

public sealed class TokenDto
{
    public Guid Id { get; set; }
    public Guid BranchId { get; set; }
    public Guid ServiceTypeId { get; set; }
    public string ServiceTypeName { get; set; } = "";
    public string TokenNo { get; set; } = "";
    public TokenStatus Status { get; set; }
    public DateTime IssuedAtUtc { get; set; }
    public DateTime? CalledAtUtc { get; set; }
    public DateTime? ServedAtUtc { get; set; }
    public Guid? CurrentCounterId { get; set; }
    public string? CustomerEmail { get; set; }
}
