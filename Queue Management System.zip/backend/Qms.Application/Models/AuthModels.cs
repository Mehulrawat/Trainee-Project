namespace Qms.Application.Models;

public sealed record RegisterRequest(string Email, string Password);
public sealed record LoginRequest(string Email, string Password);

public sealed record AuthResponse(string AccessToken, string Email, string Role);
