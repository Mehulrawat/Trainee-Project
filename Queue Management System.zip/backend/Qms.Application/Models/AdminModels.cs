namespace Qms.Application.Models;

public sealed record CreateServiceTypeRequest(Guid BranchId, string Name, string Prefix);
public sealed record CreateCounterRequest(Guid BranchId, string Name);

public sealed record UpdateServiceTypeRequest(string Name, string Prefix, bool IsActive);
public sealed record UpdateCounterRequest(string Name, bool IsActive);

public sealed record AssignCounterServicesRequest(Guid CounterId, Guid[] ServiceTypeIds);

public sealed record QueueResetRequest(Guid BranchId);
