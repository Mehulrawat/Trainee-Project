# Queue Management System (QMS)

Tech stack:
- Backend: ASP.NET Core 8 (Clean Architecture style)
- Database: SQL Server (EF Core Code First)
- Real-time: SignalR
- Email: SMTP + retry worker

## 1) Run backend

1. Update `backend/Qms.Api/appsettings.json`:
   - Connection string: `ConnectionStrings:Default`
   - JWT signing key: `Jwt:SigningKey`
   - SMTP settings: `Smtp:*`

2. Run:
```bash
cd backend
dotnet restore
dotnet run --project Qms.Api
```

Swagger:
- https://localhost:5001/swagger (or the URL printed in console)

Seeded users (created on first run):
- Admin: `admin@qms.local` / `Admin123$!`
- Staff: `staff@qms.local` / `Staff123$!`
- Customer: `customer@qms.local` / `Customer123$!`

## 2) Quick API flow

1. Customer issues token:
`POST /api/tokens`
```json
{ "branchId": "<MAIN_BRANCH_GUID>", "serviceTypeId": "<SERVICE_GUID>", "customerEmail": "x@y.com" }
```

2. Staff calls next token:
`POST /api/staff/call-next` (JWT required)
```json
{ "branchId": "<MAIN_BRANCH_GUID>", "counterId": "<COUNTER_GUID>" }
```

SignalR hub:
- `/hubs/queue` (JWT required)

Client events:
- `tokenIssued`
- `tokenUpdated`
- `queueReset`

## 3) EF Core migrations (recommended)

This scaffold uses `EnsureCreated()` for simplicity.

For production, switch to migrations:
```bash
dotnet tool install --global dotnet-ef
cd backend/Qms.Api
dotnet ef migrations add InitialCreate --project ../Qms.Infrastructure --startup-project .
dotnet ef database update --project ../Qms.Infrastructure --startup-project .
```
