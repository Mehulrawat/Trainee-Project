using Microsoft.Extensions.DependencyInjection;
using Qms.Api.Security;

namespace Qms.Api.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddQmsApi(this IServiceCollection services)
    {
        services.AddSingleton<JwtTokenFactory>();
        return services;
    }
}
