using System.Security.Claims;

namespace Qms.Api.Security;

public static class UserContext
{
    public static Guid? GetUserId(ClaimsPrincipal user)
    {
        var sub = user.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier || c.Type.EndsWith("/nameidentifier") || c.Type == "sub")?.Value;
        if (Guid.TryParse(sub, out var id)) return id;
        return null;
    }
}
