using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace Qms.Api.RealTime;

[Authorize]
public sealed class QueueHub : Hub
{
    // Clients listen to "tokenIssued", "tokenUpdated", "queueReset"
}
