using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Qms.Api.Common;
using Qms.Api.Security;
using Qms.Application.Abstractions;
using Qms.Application.Models;
using Qms.Domain.Entities;
using Qms.Infrastructure.Security;

namespace Qms.Api.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly IAppDbContext _db;
    private readonly JwtTokenFactory _tokens;

    public AuthController(IAppDbContext db, JwtTokenFactory tokens)
    {
        _db = db;
        _tokens = tokens;
    }

    [HttpPost("register")]
    public async Task<ActionResult<ApiResult<AuthResponse>>> Register(RegisterRequest request, CancellationToken ct)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        if (await _db.Users.AnyAsync(u => u.Email == email, ct))
            return BadRequest(ApiResult<AuthResponse>.Fail("Email already registered."));

        var user = new AppUser { Email = email, Role = Qms.Domain.Enums.AppRole.Customer, IsActive = true };
        user.PasswordHash = PasswordHasherAdapter.HashPassword(user, request.Password);

        _db.Users.Add(user);
        await _db.SaveChangesAsync(ct);

        var token = _tokens.CreateAccessToken(user);
        return Ok(ApiResult<AuthResponse>.Success(new AuthResponse(token, user.Email, user.Role.ToString())));
    }

    [HttpPost("login")]
    public async Task<ActionResult<ApiResult<AuthResponse>>> Login(LoginRequest request, CancellationToken ct)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email, ct);
        if (user is null || !user.IsActive)
            return Unauthorized(ApiResult<AuthResponse>.Fail("Invalid credentials."));

        if (!PasswordHasherAdapter.VerifyHashedPassword(user, user.PasswordHash, request.Password))
            return Unauthorized(ApiResult<AuthResponse>.Fail("Invalid credentials."));

        var token = _tokens.CreateAccessToken(user);
        return Ok(ApiResult<AuthResponse>.Success(new AuthResponse(token, user.Email, user.Role.ToString())));
    }
}
