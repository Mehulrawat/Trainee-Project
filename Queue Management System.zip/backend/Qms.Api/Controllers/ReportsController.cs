using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Qms.Api.Common;
using Qms.Application.Abstractions;
using Qms.Domain.Enums;

namespace Qms.Api.Controllers;

[ApiController]
[Authorize(Roles = "Admin")]
[Route("api/admin/reports")]
public sealed class ReportsController : ControllerBase
{
    private readonly IAppDbContext _db;
    public ReportsController(IAppDbContext db) => _db = db;

    // Daily summary for a branch (baseline)
    [HttpGet("daily")]
    public async Task<ActionResult<ApiResult<object>>> Daily([FromQuery] Guid branchId, [FromQuery] DateTime? dayUtc, CancellationToken ct)
    {
        var day = (dayUtc ?? DateTime.UtcNow).Date;
        var next = day.AddDays(1);

        var tokens = _db.Tokens.Where(t => t.BranchId == branchId && t.IssuedAtUtc >= day && t.IssuedAtUtc < next);

        var total = await tokens.CountAsync(ct);
        var served = await tokens.CountAsync(t => t.Status == TokenStatus.Served, ct);
        var cancelled = await tokens.CountAsync(t => t.Status == TokenStatus.Cancelled, ct);
        var skipped = await tokens.CountAsync(t => t.Status == TokenStatus.Skipped, ct);

        var avgWaitMinutes = await tokens
            .Where(t => t.CalledAtUtc != null)
            .AverageAsync(t => (double?)EF.Functions.DateDiffMinute(t.IssuedAtUtc, t.CalledAtUtc!.Value), ct) ?? 0;

        return Ok(ApiResult<object>.Success(new
        {
            dayUtc = day,
            total,
            served,
            cancelled,
            skipped,
            avgWaitMinutes
        }));
    }

    // Avg wait per service type for a date range
    [HttpGet("service-avg-wait")]
    public async Task<ActionResult<ApiResult<object>>> ServiceAvgWait([FromQuery] Guid branchId, [FromQuery] DateTime fromUtc, [FromQuery] DateTime toUtc, CancellationToken ct)
    {
        var from = fromUtc.ToUniversalTime();
        var to = toUtc.ToUniversalTime();
        if (to <= from) return BadRequest(ApiResult<object>.Fail("Invalid range"));

        var q = _db.Tokens
            .Where(t => t.BranchId == branchId && t.IssuedAtUtc >= from && t.IssuedAtUtc < to && t.CalledAtUtc != null);

        var items = await q
            .GroupBy(t => new { t.ServiceTypeId, t.ServiceType.Name })
            .Select(g => new
            {
                g.Key.ServiceTypeId,
                serviceTypeName = g.Key.Name,
                count = g.Count(),
                avgWaitMinutes = g.Average(t => (double?)EF.Functions.DateDiffMinute(t.IssuedAtUtc, t.CalledAtUtc!.Value)) ?? 0
            })
            .OrderByDescending(x => x.count)
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(items));
    }

    // Counter performance: served count + avg service time
    [HttpGet("counter-performance")]
    public async Task<ActionResult<ApiResult<object>>> CounterPerformance([FromQuery] Guid branchId, [FromQuery] DateTime fromUtc, [FromQuery] DateTime toUtc, CancellationToken ct)
    {
        var from = fromUtc.ToUniversalTime();
        var to = toUtc.ToUniversalTime();
        if (to <= from) return BadRequest(ApiResult<object>.Fail("Invalid range"));

        var q = _db.Tokens
            .Where(t => t.BranchId == branchId && t.IssuedAtUtc >= from && t.IssuedAtUtc < to && t.CurrentCounterId != null);

        var items = await q
            .GroupBy(t => t.CurrentCounterId)
            .Select(g => new
            {
                counterId = g.Key,
                served = g.Count(t => t.Status == TokenStatus.Served),
                skipped = g.Count(t => t.Status == TokenStatus.Skipped),
                cancelled = g.Count(t => t.Status == TokenStatus.Cancelled),
                avgHandleMinutes = g
                    .Where(t => t.CalledAtUtc != null && t.ServedAtUtc != null)
                    .Average(t => (double?)EF.Functions.DateDiffMinute(t.CalledAtUtc!.Value, t.ServedAtUtc!.Value)) ?? 0
            })
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(items));
    }
}
