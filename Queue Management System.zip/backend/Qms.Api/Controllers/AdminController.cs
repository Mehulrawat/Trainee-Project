using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.SignalR;
using Qms.Api.Common;
using Qms.Api.RealTime;
using Qms.Api.Security;
using Qms.Application.Abstractions;
using Qms.Application.Models;
using Qms.Domain.Entities;

namespace Qms.Api.Controllers;

[ApiController]
[Authorize(Roles = "Admin")]
[Route("api/admin")]
public sealed class AdminController : ControllerBase
{
    private readonly IAppDbContext _db;
    private readonly ITokenService _tokens;
    private readonly IHubContext<QueueHub> _hub;

    public AdminController(IAppDbContext db, ITokenService tokens, IHubContext<QueueHub> hub)
    {
        _db = db;
        _tokens = tokens;
        _hub = hub;
    }

    [HttpPost("services")]
    public async Task<ActionResult<ApiResult<object>>> CreateService(CreateServiceTypeRequest req, CancellationToken ct)
    {
        var entity = new ServiceType
        {
            BranchId = req.BranchId,
            Name = req.Name,
            Prefix = req.Prefix,
            IsActive = true
        };
        _db.ServiceTypes.Add(entity);
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { entity.Id }));
    }

    [HttpGet("services")]
    public async Task<ActionResult<ApiResult<object>>> ListServices([FromQuery] Guid? branchId, CancellationToken ct)
    {
        var q = _db.ServiceTypes.AsQueryable();
        if (branchId.HasValue) q = q.Where(s => s.BranchId == branchId.Value);

        var items = await q
            .OrderBy(s => s.Name)
            .Select(s => new { s.Id, s.BranchId, s.Name, s.Prefix, s.IsActive })
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(items));
    }

    [HttpPut("services/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> UpdateService(Guid id, UpdateServiceTypeRequest req, CancellationToken ct)
    {
        var entity = await _db.ServiceTypes.FirstOrDefaultAsync(s => s.Id == id, ct);
        if (entity is null) return NotFound(ApiResult<object>.Fail("Not found"));

        entity.Name = req.Name;
        entity.Prefix = req.Prefix;
        entity.IsActive = req.IsActive;
        await _db.SaveChangesAsync(ct);

        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpDelete("services/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> DeactivateService(Guid id, CancellationToken ct)
    {
        var entity = await _db.ServiceTypes.FirstOrDefaultAsync(s => s.Id == id, ct);
        if (entity is null) return NotFound(ApiResult<object>.Fail("Not found"));

        entity.IsActive = false;
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpPost("counters")]
    public async Task<ActionResult<ApiResult<object>>> CreateCounter(CreateCounterRequest req, CancellationToken ct)
    {
        var entity = new Counter
        {
            BranchId = req.BranchId,
            Name = req.Name,
            IsActive = true
        };
        _db.Counters.Add(entity);
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { entity.Id }));
    }

    [HttpGet("counters")]
    public async Task<ActionResult<ApiResult<object>>> ListCounters([FromQuery] Guid? branchId, CancellationToken ct)
    {
        var q = _db.Counters.AsQueryable();
        if (branchId.HasValue) q = q.Where(c => c.BranchId == branchId.Value);

        var items = await q
            .OrderBy(c => c.Name)
            .Select(c => new { c.Id, c.BranchId, c.Name, c.IsActive })
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(items));
    }

    [HttpPut("counters/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> UpdateCounter(Guid id, UpdateCounterRequest req, CancellationToken ct)
    {
        var entity = await _db.Counters.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (entity is null) return NotFound(ApiResult<object>.Fail("Not found"));

        entity.Name = req.Name;
        entity.IsActive = req.IsActive;
        await _db.SaveChangesAsync(ct);

        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpDelete("counters/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> DeactivateCounter(Guid id, CancellationToken ct)
    {
        var entity = await _db.Counters.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (entity is null) return NotFound(ApiResult<object>.Fail("Not found"));

        entity.IsActive = false;
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpPost("counters/assign-services")]
    public async Task<ActionResult<ApiResult<object>>> AssignServices(AssignCounterServicesRequest req, CancellationToken ct)
    {
        // remove old
        var existing = await _db.CounterServiceTypes.Where(x => x.CounterId == req.CounterId).ToListAsync(ct);
        foreach (var e in existing) _db.CounterServiceTypes.Remove(e);

        foreach (var sid in req.ServiceTypeIds.Distinct())
        {
            _db.CounterServiceTypes.Add(new CounterServiceType { CounterId = req.CounterId, ServiceTypeId = sid });
        }

        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpGet("counters/{counterId:guid}/assigned-services")]
    public async Task<ActionResult<ApiResult<object>>> GetAssignedServices(Guid counterId, CancellationToken ct)
    {
        var ids = await _db.CounterServiceTypes
            .Where(x => x.CounterId == counterId)
            .Select(x => x.ServiceTypeId)
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(ids));
    }

    [HttpPost("queues/reset")]
    public async Task<ActionResult<ApiResult<object>>> ResetQueue(QueueResetRequest req, CancellationToken ct)
    {
        var uid = UserContext.GetUserId(User);
        if (uid is null) return Unauthorized(ApiResult<object>.Fail("Unauthorized"));

        await _tokens.ResetQueueAsync(req.BranchId, uid.Value, ct);
        await _hub.Clients.All.SendAsync("queueReset", new { req.BranchId }, ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }
}
