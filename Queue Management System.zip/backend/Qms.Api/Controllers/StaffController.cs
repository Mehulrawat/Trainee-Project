using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Qms.Api.Common;
using Qms.Api.RealTime;
using Qms.Api.Security;
using Qms.Application.Abstractions;
using Qms.Application.Models;

namespace Qms.Api.Controllers;

[ApiController]
[Authorize(Roles = "Staff,Admin")]
[Route("api/staff")]
public sealed class StaffController : ControllerBase
{
    private readonly ITokenService _tokens;
    private readonly IHubContext<QueueHub> _hub;

    public StaffController(ITokenService tokens, IHubContext<QueueHub> hub)
    {
        _tokens = tokens;
        _hub = hub;
    }

    [HttpPost("call-next")]
    public async Task<ActionResult<ApiResult<TokenDto?>>> CallNext(CallNextRequest request, CancellationToken ct)
    {
        var uid = UserContext.GetUserId(User);
        if (uid is null) return Unauthorized(ApiResult<TokenDto?>.Fail("Unauthorized"));

        var next = await _tokens.CallNextAsync(request, uid.Value, ct);
        if (next is null) return Ok(ApiResult<TokenDto?>.Success(null, "No token available or counter already serving."));

        await _hub.Clients.All.SendAsync("tokenUpdated", next, ct);
        return Ok(ApiResult<TokenDto?>.Success(next));
    }

    [HttpPost("tokens/{id:guid}/skip")]
    public async Task<ActionResult<ApiResult<TokenDto>>> Skip(Guid id, CancellationToken ct)
    {
        var uid = UserContext.GetUserId(User);
        if (uid is null) return Unauthorized(ApiResult<TokenDto>.Fail("Unauthorized"));

        var token = await _tokens.SkipAsync(id, uid.Value, ct);
        await _hub.Clients.All.SendAsync("tokenUpdated", token, ct);
        return Ok(ApiResult<TokenDto>.Success(token));
    }

    [HttpPost("tokens/{id:guid}/serve")]
    public async Task<ActionResult<ApiResult<TokenDto>>> Serve(Guid id, CancellationToken ct)
    {
        var uid = UserContext.GetUserId(User);
        if (uid is null) return Unauthorized(ApiResult<TokenDto>.Fail("Unauthorized"));

        var token = await _tokens.ServeAsync(id, uid.Value, ct);
        await _hub.Clients.All.SendAsync("tokenUpdated", token, ct);
        return Ok(ApiResult<TokenDto>.Success(token));
    }
}
