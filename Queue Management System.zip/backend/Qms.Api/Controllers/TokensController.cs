using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Qms.Api.Common;
using Qms.Api.RealTime;
using Qms.Api.Security;
using Qms.Application.Abstractions;
using Qms.Application.Models;

namespace Qms.Api.Controllers;

[ApiController]
[Route("api/tokens")]
public sealed class TokensController : ControllerBase
{
    private readonly ITokenService _tokens;
    private readonly IHubContext<QueueHub> _hub;

    public TokensController(ITokenService tokens, IHubContext<QueueHub> hub)
    {
        _tokens = tokens;
        _hub = hub;
    }

    [HttpPost]
    public async Task<ActionResult<ApiResult<TokenDto>>> Issue(IssueTokenRequest request, CancellationToken ct)
    {
        var uid = UserContext.GetUserId(User);
        var token = await _tokens.IssueTokenAsync(request, uid, ct);
        await _hub.Clients.All.SendAsync("tokenIssued", token, ct);
        return Ok(ApiResult<TokenDto>.Success(token));
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<ApiResult<TokenDto>>> Get(Guid id, CancellationToken ct)
    {
        var token = await _tokens.GetTokenAsync(id, ct);
        return token is null ? NotFound(ApiResult<TokenDto>.Fail("Not found")) : Ok(ApiResult<TokenDto>.Success(token));
    }

    [HttpGet("queue-status")]
    public async Task<ActionResult<ApiResult<IReadOnlyList<TokenDto>>>> QueueStatus([FromQuery] Guid branchId, [FromQuery] Guid serviceTypeId, CancellationToken ct)
    {
        var list = await _tokens.GetQueueStatusAsync(branchId, serviceTypeId, ct);
        return Ok(ApiResult<IReadOnlyList<TokenDto>>.Success(list));
    }

    [Authorize]
    [HttpPost("{id:guid}/cancel")]
    public async Task<ActionResult<ApiResult<TokenDto>>> Cancel(Guid id, CancellationToken ct)
    {
        var uid = UserContext.GetUserId(User);
        var token = await _tokens.CancelAsync(id, uid, ct);
        await _hub.Clients.All.SendAsync("tokenUpdated", token, ct);
        return Ok(ApiResult<TokenDto>.Success(token));
    }
}
