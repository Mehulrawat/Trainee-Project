using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Qms.Api.Common;
using Qms.Application.Abstractions;

namespace Qms.Api.Controllers;

[ApiController]
[Route("api/services")]
public sealed class ServicesController : ControllerBase
{
    private readonly IAppDbContext _db;

    public ServicesController(IAppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<ApiResult<object>>> Get([FromQuery] Guid? branchId, CancellationToken ct)
    {
        var q = _db.ServiceTypes.AsQueryable().Where(s => s.IsActive);
        if (branchId.HasValue) q = q.Where(s => s.BranchId == branchId);

        var items = await q
            .OrderBy(s => s.Name)
            .Select(s => new { s.Id, s.BranchId, s.Name, s.Prefix })
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(items));
    }
}
