using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Qms.Api.Common;
using Qms.Application.Abstractions;
using Qms.Application.Models;
using Qms.Domain.Entities;

namespace Qms.Api.Controllers;

[ApiController]
[Authorize(Roles = "Admin")]
[Route("api/admin/notifications")]
public sealed class NotificationsController : ControllerBase
{
    private readonly IAppDbContext _db;
    public NotificationsController(IAppDbContext db) => _db = db;

    // Templates
    [HttpGet("templates")]
    public async Task<ActionResult<ApiResult<object>>> ListTemplates(CancellationToken ct)
    {
        var items = await _db.EmailTemplates
            .OrderBy(t => t.Name)
            .Select(t => new { t.Id, t.Name, t.Subject, t.Body })
            .ToListAsync(ct);
        return Ok(ApiResult<object>.Success(items));
    }

    [HttpPost("templates")]
    public async Task<ActionResult<ApiResult<object>>> CreateTemplate(CreateEmailTemplateRequest req, CancellationToken ct)
    {
        var e = new EmailTemplate { Name = req.Name, Subject = req.Subject, Body = req.Body };
        _db.EmailTemplates.Add(e);
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { e.Id }));
    }

    [HttpPut("templates/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> UpdateTemplate(Guid id, UpdateEmailTemplateRequest req, CancellationToken ct)
    {
        var e = await _db.EmailTemplates.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (e is null) return NotFound(ApiResult<object>.Fail("Not found"));
        e.Name = req.Name;
        e.Subject = req.Subject;
        e.Body = req.Body;
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpDelete("templates/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> DeleteTemplate(Guid id, CancellationToken ct)
    {
        var e = await _db.EmailTemplates.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (e is null) return NotFound(ApiResult<object>.Fail("Not found"));
        _db.EmailTemplates.Remove(e);
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    // Rules
    [HttpGet("rules")]
    public async Task<ActionResult<ApiResult<object>>> ListRules(CancellationToken ct)
    {
        var items = await _db.NotificationRules
            .Include(r => r.EmailTemplate)
            .OrderBy(r => r.EventType)
            .Select(r => new
            {
                r.Id,
                r.EventType,
                r.IsEnabled,
                r.SendToCustomer,
                r.SendToStaff,
                r.StaffEmailsCsv,
                r.EmailTemplateId,
                templateName = r.EmailTemplate.Name
            })
            .ToListAsync(ct);
        return Ok(ApiResult<object>.Success(items));
    }

    [HttpPost("rules")]
    public async Task<ActionResult<ApiResult<object>>> CreateRule(CreateNotificationRuleRequest req, CancellationToken ct)
    {
        var rule = new NotificationRule
        {
            EventType = req.EventType,
            IsEnabled = req.IsEnabled,
            SendToCustomer = req.SendToCustomer,
            SendToStaff = req.SendToStaff,
            StaffEmailsCsv = req.StaffEmailsCsv,
            EmailTemplateId = req.EmailTemplateId
        };
        _db.NotificationRules.Add(rule);
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { rule.Id }));
    }

    [HttpPut("rules/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> UpdateRule(Guid id, UpdateNotificationRuleRequest req, CancellationToken ct)
    {
        var rule = await _db.NotificationRules.FirstOrDefaultAsync(r => r.Id == id, ct);
        if (rule is null) return NotFound(ApiResult<object>.Fail("Not found"));

        rule.EventType = req.EventType;
        rule.IsEnabled = req.IsEnabled;
        rule.SendToCustomer = req.SendToCustomer;
        rule.SendToStaff = req.SendToStaff;
        rule.StaffEmailsCsv = req.StaffEmailsCsv;
        rule.EmailTemplateId = req.EmailTemplateId;
        await _db.SaveChangesAsync(ct);

        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    [HttpDelete("rules/{id:guid}")]
    public async Task<ActionResult<ApiResult<object>>> DeleteRule(Guid id, CancellationToken ct)
    {
        var rule = await _db.NotificationRules.FirstOrDefaultAsync(r => r.Id == id, ct);
        if (rule is null) return NotFound(ApiResult<object>.Fail("Not found"));
        _db.NotificationRules.Remove(rule);
        await _db.SaveChangesAsync(ct);
        return Ok(ApiResult<object>.Success(new { Ok = true }));
    }

    // Delivery logs
    [HttpGet("delivery-logs")]
    public async Task<ActionResult<ApiResult<object>>> DeliveryLogs([FromQuery] int take = 100, CancellationToken ct = default)
    {
        take = Math.Clamp(take, 1, 500);
        var items = await _db.EmailDeliveryLogs
            .OrderByDescending(l => l.CreatedAtUtc)
            .Take(take)
            .Select(l => new
            {
                l.Id,
                l.TokenId,
                l.EventType,
                l.RecipientEmail,
                l.Status,
                l.AttemptCount,
                l.LastError,
                l.CreatedAtUtc,
                l.NextRetryAtUtc
            })
            .ToListAsync(ct);

        return Ok(ApiResult<object>.Success(items));
    }
}
