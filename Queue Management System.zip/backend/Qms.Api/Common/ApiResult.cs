namespace Qms.Api.Common;

public sealed class ApiResult<T>
{
    public bool Ok { get; set; }
    public string? Message { get; set; }
    public T? Data { get; set; }

    public static ApiResult<T> Success(T data, string? message = null) => new() { Ok = true, Data = data, Message = message };
    public static ApiResult<T> Fail(string message) => new() { Ok = false, Message = message };
}
