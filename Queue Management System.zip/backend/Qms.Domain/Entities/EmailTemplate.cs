using Qms.Domain.Common;

namespace Qms.Domain.Entities;

public sealed class EmailTemplate : BaseEntity
{
    public string Name { get; set; } = default!;
    public string Subject { get; set; } = default!;
    public string Body { get; set; } = default!;
}
