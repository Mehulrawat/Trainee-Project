using Qms.Domain.Common;
using Qms.Domain.Enums;

namespace Qms.Domain.Entities;

public sealed class TokenAuditLog : BaseEntity
{
    public Guid TokenId { get; set; }
    public Token Token { get; set; } = default!;

    public TokenStatus FromStatus { get; set; }
    public TokenStatus ToStatus { get; set; }

    public Guid? PerformedByUserId { get; set; }
    public AppUser? PerformedByUser { get; set; }

    public string? Note { get; set; }
}
