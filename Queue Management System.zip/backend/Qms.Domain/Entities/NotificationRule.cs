using Qms.Domain.Common;
using Qms.Domain.Enums;

namespace Qms.Domain.Entities;

public sealed class NotificationRule : BaseEntity
{
    public NotificationEventType EventType { get; set; }
    public bool IsEnabled { get; set; } = true;

    // Simple recipients: send to customer email when available, and/or to staff emails.
    public bool SendToCustomer { get; set; } = true;
    public bool SendToStaff { get; set; } = false;

    // Optional CSV list of staff emails for now (can be normalized later)
    public string? StaffEmailsCsv { get; set; }

    public Guid EmailTemplateId { get; set; }
    public EmailTemplate EmailTemplate { get; set; } = default!;
}
