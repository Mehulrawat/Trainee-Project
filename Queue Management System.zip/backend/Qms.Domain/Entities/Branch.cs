using Qms.Domain.Common;

namespace Qms.Domain.Entities;

public sealed class Branch : BaseEntity
{
    public string Name { get; set; } = default!;
    public string Code { get; set; } = default!;

    public ICollection<ServiceType> ServiceTypes { get; set; } = new List<ServiceType>();
    public ICollection<Counter> Counters { get; set; } = new List<Counter>();
}
