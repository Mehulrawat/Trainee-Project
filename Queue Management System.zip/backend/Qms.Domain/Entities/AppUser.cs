using Qms.Domain.Common;
using Qms.Domain.Enums;

namespace Qms.Domain.Entities;

public sealed class AppUser : BaseEntity
{
    public string Email { get; set; } = default!;
    public string PasswordHash { get; set; } = default!;
    public bool IsActive { get; set; } = true;
    public AppRole Role { get; set; } = AppRole.Customer;

    // Optional: link staff to a branch
    public Guid? BranchId { get; set; }
    public Branch? Branch { get; set; }
}
