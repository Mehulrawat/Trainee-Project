using Qms.Domain.Common;
using Qms.Domain.Enums;

namespace Qms.Domain.Entities;

public sealed class Token : BaseEntity
{
    public Guid BranchId { get; set; }
    public Branch Branch { get; set; } = default!;

    public Guid ServiceTypeId { get; set; }
    public ServiceType ServiceType { get; set; } = default!;

    public int SequenceNo { get; set; } // monotonically increasing per day+service (simplified)
    public string TokenNo { get; set; } = default!; // e.g., A-001

    public TokenStatus Status { get; set; } = TokenStatus.Waiting;

    public DateTime IssuedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? CalledAtUtc { get; set; }
    public DateTime? ServedAtUtc { get; set; }
    public DateTime? CancelledAtUtc { get; set; }

    public Guid? CurrentCounterId { get; set; }
    public Counter? CurrentCounter { get; set; }

    public string? CustomerEmail { get; set; }

    // SQL Server rowversion concurrency token
    public byte[] RowVersion { get; set; } = Array.Empty<byte>();

    public ICollection<TokenAuditLog> AuditLogs { get; set; } = new List<TokenAuditLog>();
}
