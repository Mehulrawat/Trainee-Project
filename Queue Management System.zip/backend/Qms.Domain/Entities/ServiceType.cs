using Qms.Domain.Common;

namespace Qms.Domain.Entities;

public sealed class ServiceType : BaseEntity
{
    public Guid BranchId { get; set; }
    public Branch Branch { get; set; } = default!;

    public string Name { get; set; } = default!;
    public string Prefix { get; set; } = "A"; // token prefix (e.g., A, B, C)
    public bool IsActive { get; set; } = true;

    public ICollection<CounterServiceType> CounterLinks { get; set; } = new List<CounterServiceType>();
    public ICollection<Token> Tokens { get; set; } = new List<Token>();
}
