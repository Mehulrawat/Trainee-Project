namespace Qms.Domain.Entities;

public sealed class CounterServiceType
{
    public Guid CounterId { get; set; }
    public Counter Counter { get; set; } = default!;

    public Guid ServiceTypeId { get; set; }
    public ServiceType ServiceType { get; set; } = default!;
}
