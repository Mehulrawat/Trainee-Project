using Qms.Domain.Common;
using Qms.Domain.Enums;

namespace Qms.Domain.Entities;

public sealed class EmailDeliveryLog : BaseEntity
{
    public Guid? TokenId { get; set; }
    public Token? Token { get; set; }

    public NotificationEventType EventType { get; set; }
    public string RecipientEmail { get; set; } = default!;
    public string Subject { get; set; } = default!;
    public string Body { get; set; } = default!;

    public EmailDeliveryStatus Status { get; set; } = EmailDeliveryStatus.Pending;
    public int AttemptCount { get; set; } = 0;
    public string? LastError { get; set; }
    public DateTime? NextRetryAtUtc { get; set; }
}
