using Qms.Domain.Common;

namespace Qms.Domain.Entities;

public sealed class Counter : BaseEntity
{
    public Guid BranchId { get; set; }
    public Branch Branch { get; set; } = default!;

    public string Name { get; set; } = default!;
    public bool IsActive { get; set; } = true;

    public ICollection<CounterServiceType> ServiceLinks { get; set; } = new List<CounterServiceType>();
}
