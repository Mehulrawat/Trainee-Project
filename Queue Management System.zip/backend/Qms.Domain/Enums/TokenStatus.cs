namespace Qms.Domain.Enums;

public enum TokenStatus
{
    Waiting = 1,
    Serving = 2,
    Served = 3,
    Skipped = 4,
    Cancelled = 5
}
