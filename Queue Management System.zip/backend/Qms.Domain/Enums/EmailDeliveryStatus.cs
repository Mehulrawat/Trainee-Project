namespace Qms.Domain.Enums;

public enum EmailDeliveryStatus
{
    Pending = 1,
    Sent = 2,
    Failed = 3
}
