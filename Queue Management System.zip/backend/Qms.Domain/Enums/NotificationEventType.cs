namespace Qms.Domain.Enums;

public enum NotificationEventType
{
    TokenIssued = 1,
    TokenCalled = 2,
    TokenSkipped = 3,
    TokenCancelled = 4,
    TokenServed = 5
}
