namespace Qms.Domain.Enums;

public enum AppRole
{
    Customer = 1,
    Staff = 2,
    Admin = 3
}
