export type ApiResult<T> = { ok: boolean; message?: string; data?: T; };

export type ServiceType = { id: string; branchId: string; name: string; prefix: string; };

export type TokenDto = {
  id: string;
  branchId: string;
  serviceTypeId: string;
  serviceTypeName: string;
  tokenNo: string;
  status: number | string;
  issuedAtUtc: string;
  calledAtUtc?: string | null;
  servedAtUtc?: string | null;
  currentCounterId?: string | null;
  customerEmail?: string | null;
};
