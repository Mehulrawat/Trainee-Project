import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { ApiResult, ServiceType, TokenDto } from './api';

@Injectable({ providedIn: 'root' })
export class QmsApiService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  services(branchId?: string) {
    const qs = branchId ? \`?branchId=\${branchId}\` : '';
    return this.http.get<ApiResult<ServiceType[]>>(\`\${this.auth.apiBase}/api/services\${qs}\`);
  }

  issueToken(payload: { branchId: string; serviceTypeId: string; customerEmail?: string | null; }) {
    return this.http.post<ApiResult<TokenDto>>(\`\${this.auth.apiBase}/api/tokens\`, payload);
  }

  queueStatus(branchId: string, serviceTypeId: string) {
    return this.http.get<ApiResult<TokenDto[]>>(\`\${this.auth.apiBase}/api/tokens/queue-status?branchId=\${branchId}&serviceTypeId=\${serviceTypeId}\`);
  }

  login(payload: { email: string; password: string; }) {
    return this.http.post<ApiResult<any>>(\`\${this.auth.apiBase}/api/auth/login\`, payload);
  }

  callNext(payload: { branchId: string; counterId: string; }) {
    return this.http.post<ApiResult<TokenDto | null>>(\`\${this.auth.apiBase}/api/staff/call-next\`, payload);
  }

  skip(tokenId: string) {
    return this.http.post<ApiResult<TokenDto>>(\`\${this.auth.apiBase}/api/staff/tokens/\${tokenId}/skip\`, {});
  }

  serve(tokenId: string) {
    return this.http.post<ApiResult<TokenDto>>(\`\${this.auth.apiBase}/api/staff/tokens/\${tokenId}/serve\`, {});
  }

  // Admin: services
  adminServices(branchId?: string) {
    const qs = branchId ? `?branchId=${branchId}` : '';
    return this.http.get<ApiResult<any[]>>(`${this.auth.apiBase}/api/admin/services${qs}`);
  }

  createService(payload: { branchId: string; name: string; prefix: string; }) {
    return this.http.post<ApiResult<any>>(`${this.auth.apiBase}/api/admin/services`, payload);
  }

  updateService(id: string, payload: { name: string; prefix: string; isActive: boolean; }) {
    return this.http.put<ApiResult<any>>(`${this.auth.apiBase}/api/admin/services/${id}`, payload);
  }

  deactivateService(id: string) {
    return this.http.delete<ApiResult<any>>(`${this.auth.apiBase}/api/admin/services/${id}`);
  }

  // Admin: counters
  adminCounters(branchId?: string) {
    const qs = branchId ? `?branchId=${branchId}` : '';
    return this.http.get<ApiResult<any[]>>(`${this.auth.apiBase}/api/admin/counters${qs}`);
  }

  createCounter(payload: { branchId: string; name: string; }) {
    return this.http.post<ApiResult<any>>(`${this.auth.apiBase}/api/admin/counters`, payload);
  }

  updateCounter(id: string, payload: { name: string; isActive: boolean; }) {
    return this.http.put<ApiResult<any>>(`${this.auth.apiBase}/api/admin/counters/${id}`, payload);
  }

  deactivateCounter(id: string) {
    return this.http.delete<ApiResult<any>>(`${this.auth.apiBase}/api/admin/counters/${id}`);
  }

  assignCounterServices(payload: { counterId: string; serviceTypeIds: string[]; }) {
    return this.http.post<ApiResult<any>>(`${this.auth.apiBase}/api/admin/counters/assign-services`, payload);
  }

  counterAssignedServices(counterId: string) {
    return this.http.get<ApiResult<string[]>>(`${this.auth.apiBase}/api/admin/counters/${counterId}/assigned-services`);
  }

  resetQueue(payload: { branchId: string; }) {
    return this.http.post<ApiResult<any>>(`${this.auth.apiBase}/api/admin/queues/reset`, payload);
  }

  // Admin: reports
  reportDaily(branchId: string, dayUtc?: string) {
    const day = dayUtc ? `&dayUtc=${encodeURIComponent(dayUtc)}` : '';
    return this.http.get<ApiResult<any>>(`${this.auth.apiBase}/api/admin/reports/daily?branchId=${branchId}${day}`);
  }

  reportServiceAvgWait(branchId: string, fromUtc: string, toUtc: string) {
    return this.http.get<ApiResult<any>>(`${this.auth.apiBase}/api/admin/reports/service-avg-wait?branchId=${branchId}&fromUtc=${encodeURIComponent(fromUtc)}&toUtc=${encodeURIComponent(toUtc)}`);
  }

  reportCounterPerformance(branchId: string, fromUtc: string, toUtc: string) {
    return this.http.get<ApiResult<any>>(`${this.auth.apiBase}/api/admin/reports/counter-performance?branchId=${branchId}&fromUtc=${encodeURIComponent(fromUtc)}&toUtc=${encodeURIComponent(toUtc)}`);
  }

  // Admin: notifications
  notifTemplates() {
    return this.http.get<ApiResult<any[]>>(`${this.auth.apiBase}/api/admin/notifications/templates`);
  }

  createTemplate(payload: { name: string; subject: string; body: string; }) {
    return this.http.post<ApiResult<any>>(`${this.auth.apiBase}/api/admin/notifications/templates`, payload);
  }

  updateTemplate(id: string, payload: { name: string; subject: string; body: string; }) {
    return this.http.put<ApiResult<any>>(`${this.auth.apiBase}/api/admin/notifications/templates/${id}`, payload);
  }

  deleteTemplate(id: string) {
    return this.http.delete<ApiResult<any>>(`${this.auth.apiBase}/api/admin/notifications/templates/${id}`);
  }

  notifRules() {
    return this.http.get<ApiResult<any[]>>(`${this.auth.apiBase}/api/admin/notifications/rules`);
  }

  createRule(payload: any) {
    return this.http.post<ApiResult<any>>(`${this.auth.apiBase}/api/admin/notifications/rules`, payload);
  }

  updateRule(id: string, payload: any) {
    return this.http.put<ApiResult<any>>(`${this.auth.apiBase}/api/admin/notifications/rules/${id}`, payload);
  }

  deleteRule(id: string) {
    return this.http.delete<ApiResult<any>>(`${this.auth.apiBase}/api/admin/notifications/rules/${id}`);
  }

  deliveryLogs(take: number = 100) {
    return this.http.get<ApiResult<any[]>>(`${this.auth.apiBase}/api/admin/notifications/delivery-logs?take=${take}`);
  }
}
