import { Injectable } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class RealtimeService {
  private conn?: signalR.HubConnection;

  constructor(private auth: AuthService) {}

  async connect(onMessage: (event: string, payload: any) => void) {
    const token = this.auth.token;
    if (!token) return;

    this.conn = new signalR.HubConnectionBuilder()
      .withUrl(\`\${this.auth.apiBase}/hubs/queue\`, { accessTokenFactory: () => token })
      .withAutomaticReconnect()
      .build();

    this.conn.on('tokenIssued', (p) => onMessage('tokenIssued', p));
    this.conn.on('tokenUpdated', (p) => onMessage('tokenUpdated', p));
    this.conn.on('queueReset', (p) => onMessage('queueReset', p));

    await this.conn.start();
  }

  async disconnect() {
    await this.conn?.stop();
  }
}
