import { Injectable } from '@angular/core';

type AuthResponse = { accessToken: string; email: string; role: string; };

@Injectable({ providedIn: 'root' })
export class AuthService {
  // Change this to your backend URL
  apiBase = 'https://localhost:5001';

  get token(): string | null { return localStorage.getItem('qms_token'); }
  get role(): string | null { return localStorage.getItem('qms_role'); }

  isLoggedIn(): boolean { return !!this.token; }

  setAuth(res: AuthResponse) {
    localStorage.setItem('qms_token', res.accessToken);
    localStorage.setItem('qms_role', res.role);
    localStorage.setItem('qms_email', res.email);
  }

  logout() {
    localStorage.removeItem('qms_token');
    localStorage.removeItem('qms_role');
    localStorage.removeItem('qms_email');
  }
}
