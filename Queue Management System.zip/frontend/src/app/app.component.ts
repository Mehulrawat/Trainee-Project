import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  template: \`
    <div class="container">
      <div class="row" style="align-items:center; justify-content:space-between;">
        <h2 style="margin:0;">Queue Management System</h2>

        <div class="row" style="gap:10px; align-items:center;">
          <a class="btn" routerLink="/customer">Customer</a>
          <a class="btn" routerLink="/staff">Staff</a>
          <a class="btn" routerLink="/admin">Admin</a>
          <a class="btn" routerLink="/login" *ngIf="!auth.isLoggedIn()">Login</a>
          <button class="btn" (click)="auth.logout()" *ngIf="auth.isLoggedIn()">Logout</button>
        </div>
      </div>

      <div class="small">API base: {{auth.apiBase}}</div>
      <router-outlet></router-outlet>
    </div>
  \`
})
export class AppComponent {
  constructor(public auth: AuthService) {}
}
