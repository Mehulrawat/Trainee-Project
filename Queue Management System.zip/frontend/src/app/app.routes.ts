import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login.component';
import { CustomerComponent } from './pages/customer.component';
import { StaffComponent } from './pages/staff.component';
import { AdminComponent } from './pages/admin.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'customer' },
  { path: 'login', component: LoginComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'staff', component: StaffComponent },
  { path: 'admin', component: AdminComponent },
];
