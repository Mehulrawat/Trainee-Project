import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { QmsApiService } from '../core/qms-api.service';
import { AuthService } from '../core/auth.service';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: \`
    <div class="card" style="margin-top:16px;">
      <h3>Login</h3>
      <div class="row">
        <input style="min-width:260px;" [(ngModel)]="email" placeholder="Email" />
        <input style="min-width:260px;" [(ngModel)]="password" placeholder="Password" type="password" />
        <button class="btn" (click)="login()">Login</button>
      </div>
      <div class="small" style="margin-top:10px;">Seeded: admin@qms.local / Admin123$!, staff@qms.local / Staff123$!</div>
      <div class="small" style="margin-top:10px;" *ngIf="msg">{{msg}}</div>
    </div>
  \`
})
export class LoginComponent {
  email = 'staff@qms.local';
  password = 'Staff123$!';
  msg = '';

  constructor(private api: QmsApiService, private auth: AuthService, private router: Router) {}

  login() {
    this.msg = '';
    this.api.login({ email: this.email, password: this.password }).subscribe({
      next: (res) => {
        if (!res.ok || !res.data) { this.msg = res.message || 'Login failed'; return; }
        this.auth.setAuth(res.data);
        this.router.navigateByUrl('/staff');
      },
      error: (e) => this.msg = e?.message || 'Error'
    });
  }
}
