import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgFor, NgIf } from '@angular/common';
import { QmsApiService } from '../core/qms-api.service';

type Tab = 'services' | 'counters' | 'reports' | 'notifications' | 'emailLogs';

@Component({
  standalone: true,
  imports: [FormsModule, NgIf, NgFor],
  template: `
    <div class="card" style="margin-top:16px;">
      <h3>Admin Dashboard</h3>
      <div class="small">Login required. Seeded admin: admin@qms.local / Admin123$!</div>

      <div class="row" style="margin-top:12px; flex-wrap:wrap;">
        <button class="btn" (click)="tab='services'">Services</button>
        <button class="btn" (click)="tab='counters'">Counters</button>
        <button class="btn" (click)="tab='reports'">Reports</button>
        <button class="btn" (click)="tab='notifications'">Notifications</button>
        <button class="btn" (click)="tab='emailLogs'">Email Logs</button>
      </div>

      <div class="row" style="margin-top:12px;">
        <input [(ngModel)]="branchId" placeholder="BranchId" style="min-width:340px;" />
        <button class="btn" (click)="reloadAll()" [disabled]="!branchId">Reload</button>
      </div>

      <!-- Services -->
      <div *ngIf="tab==='services'" class="card" style="margin-top:12px;">
        <h4>Service Types</h4>
        <div class="row" style="margin-top:8px; flex-wrap:wrap;">
          <input [(ngModel)]="newServiceName" placeholder="Name" style="min-width:220px;" />
          <input [(ngModel)]="newServicePrefix" placeholder="Prefix" style="min-width:120px;" />
          <button class="btn" (click)="createService()" [disabled]="!branchId || !newServiceName || !newServicePrefix">Create</button>
        </div>

        <div class="small" style="margin-top:10px;">Click a row to edit.</div>
        <table class="tbl" style="width:100%; margin-top:8px;">
          <thead>
            <tr><th>Name</th><th>Prefix</th><th>Active</th><th style="width:220px;">Actions</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let s of services" (click)="selectService(s)" style="cursor:pointer;">
              <td>{{s.name}}</td>
              <td>{{s.prefix}}</td>
              <td>{{s.isActive}}</td>
              <td>
                <button class="btn" (click)="deactivateService(s.id); $event.stopPropagation();">Deactivate</button>
              </td>
            </tr>
          </tbody>
        </table>

        <div *ngIf="editService" class="card" style="margin-top:12px;">
          <b>Edit Service</b>
          <div class="row" style="margin-top:8px; flex-wrap:wrap;">
            <input [(ngModel)]="editService.name" placeholder="Name" style="min-width:220px;" />
            <input [(ngModel)]="editService.prefix" placeholder="Prefix" style="min-width:120px;" />
            <label style="display:flex; align-items:center; gap:6px;">
              <input type="checkbox" [(ngModel)]="editService.isActive" /> Active
            </label>
            <button class="btn" (click)="saveService()">Save</button>
            <button class="btn" (click)="editService=null">Cancel</button>
          </div>
        </div>
      </div>

      <!-- Counters -->
      <div *ngIf="tab==='counters'" class="card" style="margin-top:12px;">
        <h4>Counters</h4>
        <div class="row" style="margin-top:8px; flex-wrap:wrap;">
          <input [(ngModel)]="newCounterName" placeholder="Counter name" style="min-width:260px;" />
          <button class="btn" (click)="createCounter()" [disabled]="!branchId || !newCounterName">Create</button>
        </div>

        <table class="tbl" style="width:100%; margin-top:8px;">
          <thead>
            <tr><th>Name</th><th>Active</th><th style="width:320px;">Actions</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let c of counters" style="cursor:pointer;" (click)="selectCounter(c)">
              <td>{{c.name}}</td>
              <td>{{c.isActive}}</td>
              <td>
                <button class="btn" (click)="deactivateCounter(c.id); $event.stopPropagation();">Deactivate</button>
              </td>
            </tr>
          </tbody>
        </table>

        <div *ngIf="editCounter" class="card" style="margin-top:12px;">
          <b>Edit Counter</b>
          <div class="row" style="margin-top:8px; flex-wrap:wrap;">
            <input [(ngModel)]="editCounter.name" placeholder="Name" style="min-width:260px;" />
            <label style="display:flex; align-items:center; gap:6px;">
              <input type="checkbox" [(ngModel)]="editCounter.isActive" /> Active
            </label>
            <button class="btn" (click)="saveCounter()">Save</button>
            <button class="btn" (click)="editCounter=null">Cancel</button>
          </div>

          <div class="card" style="margin-top:12px;">
            <b>Assign Services</b>
            <div class="small">Select services this counter can serve.</div>
            <div style="display:flex; flex-wrap:wrap; gap:12px; margin-top:8px;">
              <label *ngFor="let s of services" style="display:flex; align-items:center; gap:6px;">
                <input type="checkbox" [checked]="assignedServiceIds.has(s.id)" (change)="toggleAssign(s.id, $event.target.checked)" />
                {{s.name}} ({{s.prefix}})
              </label>
            </div>
            <div class="row" style="margin-top:10px;">
              <button class="btn" (click)="saveAssignments()" [disabled]="!editCounter">Save Assignments</button>
            </div>
          </div>
        </div>

        <div class="card" style="margin-top:12px;">
          <b>Queue Reset</b>
          <div class="small">Resets waiting/serving tokens for the branch.</div>
          <button class="btn" style="margin-top:8px;" (click)="resetQueue()" [disabled]="!branchId">Reset Queue</button>
        </div>
      </div>

      <!-- Reports -->
      <div *ngIf="tab==='reports'" class="card" style="margin-top:12px;">
        <h4>Reports</h4>
        <div class="row" style="margin-top:8px; flex-wrap:wrap;">
          <input [(ngModel)]="reportDay" placeholder="Day UTC (YYYY-MM-DD) optional" style="min-width:260px;" />
          <button class="btn" (click)="loadDaily()" [disabled]="!branchId">Daily Summary</button>
        </div>

        <div class="row" style="margin-top:8px; flex-wrap:wrap;">
          <input [(ngModel)]="fromUtc" placeholder="From UTC (e.g. 2025-12-01T00:00:00Z)" style="min-width:360px;" />
          <input [(ngModel)]="toUtc" placeholder="To UTC (e.g. 2025-12-31T00:00:00Z)" style="min-width:360px;" />
          <button class="btn" (click)="loadServiceAvgWait()" [disabled]="!branchId || !fromUtc || !toUtc">Avg Wait by Service</button>
          <button class="btn" (click)="loadCounterPerf()" [disabled]="!branchId || !fromUtc || !toUtc">Counter Performance</button>
        </div>

        <pre style="margin-top:10px; white-space:pre-wrap;">{{reportJson}}</pre>
      </div>

      <!-- Notifications -->
      <div *ngIf="tab==='notifications'" class="card" style="margin-top:12px;">
        <h4>Email Templates</h4>
        <div class="row" style="margin-top:8px; flex-wrap:wrap;">
          <input [(ngModel)]="tplName" placeholder="Name" style="min-width:220px;" />
          <input [(ngModel)]="tplSubject" placeholder="Subject" style="min-width:360px;" />
          <button class="btn" (click)="createTemplate()" [disabled]="!tplName || !tplSubject || !tplBody">Create</button>
        </div>
        <textarea [(ngModel)]="tplBody" placeholder="Body (use {{TokenNo}}, {{Status}}, {{BranchId}}, {{ServiceTypeId}})" style="width:100%; min-height:90px; margin-top:8px;"></textarea>

        <table class="tbl" style="width:100%; margin-top:10px;">
          <thead><tr><th>Name</th><th>Subject</th><th style="width:160px;">Actions</th></tr></thead>
          <tbody>
            <tr *ngFor="let t of templates" (click)="selectTemplate(t)" style="cursor:pointer;">
              <td>{{t.name}}</td>
              <td>{{t.subject}}</td>
              <td><button class="btn" (click)="deleteTemplate(t.id); $event.stopPropagation();">Delete</button></td>
            </tr>
          </tbody>
        </table>

        <div *ngIf="editTemplate" class="card" style="margin-top:12px;">
          <b>Edit Template</b>
          <div class="row" style="margin-top:8px; flex-wrap:wrap;">
            <input [(ngModel)]="editTemplate.name" placeholder="Name" style="min-width:220px;" />
            <input [(ngModel)]="editTemplate.subject" placeholder="Subject" style="min-width:360px;" />
            <button class="btn" (click)="saveTemplate()">Save</button>
            <button class="btn" (click)="editTemplate=null">Cancel</button>
          </div>
          <textarea [(ngModel)]="editTemplate.body" style="width:100%; min-height:90px; margin-top:8px;"></textarea>
        </div>

        <h4 style="margin-top:16px;">Notification Rules</h4>
        <div class="row" style="margin-top:8px; flex-wrap:wrap;">
          <select [(ngModel)]="ruleEventType" style="min-width:220px;">
            <option value="TokenIssued">TokenIssued</option>
            <option value="TokenCalled">TokenCalled</option>
            <option value="TokenSkipped">TokenSkipped</option>
            <option value="TokenCancelled">TokenCancelled</option>
            <option value="TokenServed">TokenServed</option>
          </select>
          <select [(ngModel)]="ruleTemplateId" style="min-width:260px;">
            <option [ngValue]="''">Select template</option>
            <option *ngFor="let t of templates" [ngValue]="t.id">{{t.name}}</option>
          </select>
          <label style="display:flex; align-items:center; gap:6px;"><input type="checkbox" [(ngModel)]="ruleEnabled" /> Enabled</label>
          <label style="display:flex; align-items:center; gap:6px;"><input type="checkbox" [(ngModel)]="sendCustomer" /> To customer</label>
          <label style="display:flex; align-items:center; gap:6px;"><input type="checkbox" [(ngModel)]="sendStaff" /> To staff</label>
          <input [(ngModel)]="staffEmailsCsv" placeholder="Staff emails CSV" style="min-width:360px;" />
          <button class="btn" (click)="createRule()" [disabled]="!ruleTemplateId">Create Rule</button>
        </div>

        <table class="tbl" style="width:100%; margin-top:10px;">
          <thead><tr><th>Event</th><th>Enabled</th><th>Customer</th><th>Staff</th><th>Template</th><th style="width:160px;">Actions</th></tr></thead>
          <tbody>
            <tr *ngFor="let r of rules" (click)="selectRule(r)" style="cursor:pointer;">
              <td>{{r.eventType}}</td>
              <td>{{r.isEnabled}}</td>
              <td>{{r.sendToCustomer}}</td>
              <td>{{r.sendToStaff}}</td>
              <td>{{r.templateName}}</td>
              <td><button class="btn" (click)="deleteRule(r.id); $event.stopPropagation();">Delete</button></td>
            </tr>
          </tbody>
        </table>

        <div *ngIf="editRule" class="card" style="margin-top:12px;">
          <b>Edit Rule</b>
          <div class="row" style="margin-top:8px; flex-wrap:wrap;">
            <select [(ngModel)]="editRule.eventType" style="min-width:220px;">
              <option value="TokenIssued">TokenIssued</option>
              <option value="TokenCalled">TokenCalled</option>
              <option value="TokenSkipped">TokenSkipped</option>
              <option value="TokenCancelled">TokenCancelled</option>
              <option value="TokenServed">TokenServed</option>
            </select>
            <select [(ngModel)]="editRule.emailTemplateId" style="min-width:260px;">
              <option *ngFor="let t of templates" [ngValue]="t.id">{{t.name}}</option>
            </select>
            <label style="display:flex; align-items:center; gap:6px;"><input type="checkbox" [(ngModel)]="editRule.isEnabled" /> Enabled</label>
            <label style="display:flex; align-items:center; gap:6px;"><input type="checkbox" [(ngModel)]="editRule.sendToCustomer" /> To customer</label>
            <label style="display:flex; align-items:center; gap:6px;"><input type="checkbox" [(ngModel)]="editRule.sendToStaff" /> To staff</label>
            <input [(ngModel)]="editRule.staffEmailsCsv" placeholder="Staff emails CSV" style="min-width:360px;" />
            <button class="btn" (click)="saveRule()">Save</button>
            <button class="btn" (click)="editRule=null">Cancel</button>
          </div>
        </div>
      </div>

      <!-- Email Logs -->
      <div *ngIf="tab==='emailLogs'" class="card" style="margin-top:12px;">
        <h4>Email Delivery Logs</h4>
        <div class="row" style="margin-top:8px;">
          <input [(ngModel)]="logTake" type="number" placeholder="Take" style="min-width:140px;" />
          <button class="btn" (click)="loadEmailLogs()">Load</button>
        </div>
        <table class="tbl" style="width:100%; margin-top:10px;">
          <thead><tr><th>Event</th><th>To</th><th>Status</th><th>Attempts</th><th>NextRetry</th></tr></thead>
          <tbody>
            <tr *ngFor="let l of logs">
              <td>{{l.eventType}}</td>
              <td>{{l.recipientEmail}}</td>
              <td>{{l.status}}</td>
              <td>{{l.attemptCount}}</td>
              <td>{{l.nextRetryAtUtc}}</td>
            </tr>
          </tbody>
        </table>
        <div class="small" *ngIf="msg" style="margin-top:10px;">{{msg}}</div>
      </div>

      <div class="small" *ngIf="msg" style="margin-top:12px;">{{msg}}</div>
    </div>
  `
})
export class AdminComponent implements OnInit {
  tab: Tab = 'services';
  branchId = '';
  msg = '';

  services: any[] = [];
  counters: any[] = [];
  templates: any[] = [];
  rules: any[] = [];
  logs: any[] = [];

  // services
  newServiceName = '';
  newServicePrefix = '';
  editService: any | null = null;

  // counters
  newCounterName = '';
  editCounter: any | null = null;
  assignedServiceIds = new Set<string>();

  // reports
  reportJson = '';
  reportDay = '';
  fromUtc = '';
  toUtc = '';

  // templates
  tplName = '';
  tplSubject = '';
  tplBody = '';
  editTemplate: any | null = null;

  // rules
  ruleEventType = 'TokenIssued';
  ruleTemplateId = '';
  ruleEnabled = true;
  sendCustomer = true;
  sendStaff = false;
  staffEmailsCsv = '';
  editRule: any | null = null;

  // logs
  logTake = 100;

  constructor(private api: QmsApiService) {}

  ngOnInit(): void {}

  reloadAll() {
    this.loadServices();
    this.loadCounters();
    this.loadTemplates();
    this.loadRules();
  }

  // --- Services ---
  loadServices() {
    this.api.adminServices(this.branchId).subscribe({
      next: r => this.services = (r.data as any) || [],
      error: e => this.msg = e?.message || 'Error'
    });
  }

  createService() {
    this.api.createService({ branchId: this.branchId, name: this.newServiceName, prefix: this.newServicePrefix }).subscribe({
      next: _ => { this.newServiceName=''; this.newServicePrefix=''; this.loadServices(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  selectService(s: any) { this.editService = { ...s }; }

  saveService() {
    if (!this.editService) return;
    this.api.updateService(this.editService.id, { name: this.editService.name, prefix: this.editService.prefix, isActive: this.editService.isActive }).subscribe({
      next: _ => { this.editService=null; this.loadServices(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  deactivateService(id: string) {
    this.api.deactivateService(id).subscribe({
      next: _ => this.loadServices(),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  // --- Counters ---
  loadCounters() {
    this.api.adminCounters(this.branchId).subscribe({
      next: r => this.counters = (r.data as any) || [],
      error: e => this.msg = e?.message || 'Error'
    });
  }

  createCounter() {
    this.api.createCounter({ branchId: this.branchId, name: this.newCounterName }).subscribe({
      next: _ => { this.newCounterName=''; this.loadCounters(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  selectCounter(c: any) {
    this.editCounter = { ...c };
    this.assignedServiceIds = new Set<string>();
    this.api.counterAssignedServices(c.id).subscribe({
      next: r => {
        const ids = (r.data as any) || [];
        this.assignedServiceIds = new Set<string>(ids);
      }
    });
  }

  saveCounter() {
    if (!this.editCounter) return;
    this.api.updateCounter(this.editCounter.id, { name: this.editCounter.name, isActive: this.editCounter.isActive }).subscribe({
      next: _ => { this.editCounter=null; this.loadCounters(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  deactivateCounter(id: string) {
    this.api.deactivateCounter(id).subscribe({
      next: _ => this.loadCounters(),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  toggleAssign(serviceId: string, checked: boolean) {
    if (checked) this.assignedServiceIds.add(serviceId);
    else this.assignedServiceIds.delete(serviceId);
  }

  saveAssignments() {
    if (!this.editCounter) return;
    this.api.assignCounterServices({ counterId: this.editCounter.id, serviceTypeIds: Array.from(this.assignedServiceIds) }).subscribe({
      next: _ => this.msg = 'Assignments saved.',
      error: e => this.msg = e?.message || 'Error'
    });
  }

  resetQueue() {
    this.api.resetQueue({ branchId: this.branchId }).subscribe({
      next: r => this.msg = r.message || 'Queue reset.',
      error: e => this.msg = e?.message || 'Error'
    });
  }

  // --- Reports ---
  loadDaily() {
    this.api.reportDaily(this.branchId, this.reportDay || undefined).subscribe({
      next: r => this.reportJson = JSON.stringify(r.data, null, 2),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  loadServiceAvgWait() {
    this.api.reportServiceAvgWait(this.branchId, this.fromUtc, this.toUtc).subscribe({
      next: r => this.reportJson = JSON.stringify(r.data, null, 2),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  loadCounterPerf() {
    this.api.reportCounterPerformance(this.branchId, this.fromUtc, this.toUtc).subscribe({
      next: r => this.reportJson = JSON.stringify(r.data, null, 2),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  // --- Notifications ---
  loadTemplates() {
    this.api.notifTemplates().subscribe({
      next: r => this.templates = (r.data as any) || [],
      error: e => this.msg = e?.message || 'Error'
    });
  }

  createTemplate() {
    this.api.createTemplate({ name: this.tplName, subject: this.tplSubject, body: this.tplBody }).subscribe({
      next: _ => { this.tplName=''; this.tplSubject=''; this.tplBody=''; this.loadTemplates(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  selectTemplate(t: any) { this.editTemplate = { ...t }; }

  saveTemplate() {
    if (!this.editTemplate) return;
    this.api.updateTemplate(this.editTemplate.id, { name: this.editTemplate.name, subject: this.editTemplate.subject, body: this.editTemplate.body }).subscribe({
      next: _ => { this.editTemplate=null; this.loadTemplates(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  deleteTemplate(id: string) {
    this.api.deleteTemplate(id).subscribe({
      next: _ => this.loadTemplates(),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  loadRules() {
    this.api.notifRules().subscribe({
      next: r => this.rules = (r.data as any) || [],
      error: e => this.msg = e?.message || 'Error'
    });
  }

  createRule() {
    this.api.createRule({
      eventType: this.ruleEventType,
      isEnabled: this.ruleEnabled,
      sendToCustomer: this.sendCustomer,
      sendToStaff: this.sendStaff,
      staffEmailsCsv: this.staffEmailsCsv || null,
      emailTemplateId: this.ruleTemplateId
    }).subscribe({
      next: _ => { this.loadRules(); this.msg='Rule created.'; },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  selectRule(r: any) { this.editRule = { ...r }; }

  saveRule() {
    if (!this.editRule) return;
    this.api.updateRule(this.editRule.id, {
      eventType: this.editRule.eventType,
      isEnabled: this.editRule.isEnabled,
      sendToCustomer: this.editRule.sendToCustomer,
      sendToStaff: this.editRule.sendToStaff,
      staffEmailsCsv: this.editRule.staffEmailsCsv || null,
      emailTemplateId: this.editRule.emailTemplateId
    }).subscribe({
      next: _ => { this.editRule=null; this.loadRules(); },
      error: e => this.msg = e?.message || 'Error'
    });
  }

  deleteRule(id: string) {
    this.api.deleteRule(id).subscribe({
      next: _ => this.loadRules(),
      error: e => this.msg = e?.message || 'Error'
    });
  }

  // --- Logs ---
  loadEmailLogs() {
    this.api.deliveryLogs(this.logTake || 100).subscribe({
      next: r => this.logs = (r.data as any) || [],
      error: e => this.msg = e?.message || 'Error'
    });
  }
}
