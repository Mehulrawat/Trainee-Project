import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { QmsApiService } from '../core/qms-api.service';
import { TokenDto } from '../core/api';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: \`
    <div class="card" style="margin-top:16px;">
      <h3>Staff Dashboard</h3>
      <div class="small">Login required. Seeded staff: staff@qms.local / Staff123$!</div>

      <div class="row" style="margin-top:12px;">
        <input [(ngModel)]="branchId" placeholder="BranchId" style="min-width:340px;" />
        <input [(ngModel)]="counterId" placeholder="CounterId" style="min-width:340px;" />
        <button class="btn" (click)="callNext()">Call Next</button>
      </div>

      <div class="card" style="margin-top:12px;" *ngIf="current">
        <div><b>Current:</b> {{current.tokenNo}} — {{current.status}}</div>
        <div class="row" style="margin-top:10px;">
          <button class="btn" (click)="skip()" [disabled]="!current">Skip</button>
          <button class="btn" (click)="serve()" [disabled]="!current">Serve</button>
        </div>
      </div>

      <div class="small" *ngIf="msg">{{msg}}</div>
    </div>
  \`
})
export class StaffComponent {
  branchId = '';
  counterId = '';
  current?: TokenDto | null;
  msg = '';

  constructor(private api: QmsApiService) {}

  callNext() {
    this.msg = '';
    this.api.callNext({ branchId: this.branchId, counterId: this.counterId }).subscribe({
      next: (res) => { this.current = (res.data as any) || null; this.msg = res.message || ''; },
      error: (e) => this.msg = e?.message || 'Error'
    });
  }

  skip() {
    if (!this.current) return;
    this.api.skip(this.current.id).subscribe(res => this.current = res.data as any);
  }

  serve() {
    if (!this.current) return;
    this.api.serve(this.current.id).subscribe(res => this.current = res.data as any);
  }
}
