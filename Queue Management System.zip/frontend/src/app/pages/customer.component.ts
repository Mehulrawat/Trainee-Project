import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { QmsApiService } from '../core/qms-api.service';
import { RealtimeService } from '../core/realtime.service';
import { ServiceType, TokenDto } from '../core/api';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: \`
    <div class="card" style="margin-top:16px;">
      <h3>Customer</h3>

      <div class="row">
        <input [(ngModel)]="branchId" placeholder="BranchId (from DB seed)" style="min-width:340px;" />
        <button class="btn" (click)="loadServices()">Load Services</button>
      </div>

      <div class="row" style="margin-top:12px;">
        <select [(ngModel)]="serviceTypeId" style="min-width:340px;">
          <option [ngValue]="''">Select service</option>
          <option *ngFor="let s of services" [ngValue]="s.id">{{s.name}} ({{s.prefix}})</option>
        </select>

        <input [(ngModel)]="customerEmail" placeholder="Email (optional)" style="min-width:260px;" />
        <button class="btn" (click)="issue()" [disabled]="!branchId || !serviceTypeId">Generate Token</button>
        <button class="btn" (click)="refreshQueue()" [disabled]="!branchId || !serviceTypeId">Refresh Queue</button>
      </div>

      <div class="card" style="margin-top:12px;" *ngIf="lastToken">
        <div><b>Your Token:</b> {{lastToken.tokenNo}} — {{lastToken.status}}</div>
        <div class="small">Issued: {{lastToken.issuedAtUtc}}</div>
      </div>

      <div class="card" style="margin-top:12px;">
        <b>Queue</b>
        <div class="small">Real-time updates require login (JWT) to connect to SignalR.</div>
        <ul>
          <li *ngFor="let t of queue">{{t.tokenNo}} — {{t.status}} ({{t.serviceTypeName}})</li>
        </ul>
      </div>

      <div class="small" *ngIf="msg">{{msg}}</div>
    </div>
  \`
})
export class CustomerComponent implements OnInit, OnDestroy {
  branchId = '';
  serviceTypeId = '';
  customerEmail = '';
  services: ServiceType[] = [];
  queue: TokenDto[] = [];
  lastToken?: TokenDto;
  msg = '';

  constructor(private api: QmsApiService, private rt: RealtimeService) {}

  ngOnInit(): void {}

  ngOnDestroy(): void { this.rt.disconnect(); }

  loadServices() {
    this.api.services(this.branchId).subscribe(res => {
      this.services = (res.data as any) || [];
    });
  }

  issue() {
    this.msg = '';
    this.api.issueToken({ branchId: this.branchId, serviceTypeId: this.serviceTypeId, customerEmail: this.customerEmail || null })
      .subscribe({
        next: (res) => { if (res.ok && res.data) { this.lastToken = res.data; this.refreshQueue(); } else { this.msg = res.message || 'Failed'; } },
        error: (e) => this.msg = e?.message || 'Error'
      });
  }

  refreshQueue() {
    this.api.queueStatus(this.branchId, this.serviceTypeId).subscribe(res => {
      this.queue = (res.data as any) || [];
    });
  }
}
