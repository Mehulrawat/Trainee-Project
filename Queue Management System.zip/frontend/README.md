# QMS Web (Angular 20)

## Run
```bash
npm install
npm start
```

## Configure API base
Edit: `src/app/core/auth.service.ts`
```ts
apiBase = 'https://localhost:5001';
```

## Notes
- Real-time SignalR connection requires JWT (login first), because the backend hub is protected.
