# Online MCQ – Frontend (Angular 20.3.8)

## Run
```bash
cd frontend
npm install
npm start
```

## Notes
- Update API base URL in `src/environments/environment.ts`
- Dedicated Exam Runner forces fullscreen and logs exit as proctoring violation.

## Examiner/Admin UI
- /examiner
- /examiner/questions
- /examiner/exams
- /examiner/reports
