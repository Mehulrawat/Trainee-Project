import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-watermark',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="wm" *ngIf="auth.isLoggedIn()">
    <div class="wm-inner">
      {{auth.userFullName()}} | {{auth.userEmail()}} | {{auth.userRole()}} | {{now}}
    </div>
  </div>
  `,
  styles: [`
    .wm{pointer-events:none;position:fixed;inset:0;opacity:0.12;z-index:9999;overflow:hidden;}
    .wm-inner{width:200%;transform:rotate(-20deg);font-size:14px;line-height:60px;white-space:nowrap;}
  `]
})
export class WatermarkComponent {
  now = new Date().toISOString();
  constructor(public auth: AuthService){ setInterval(()=> this.now = new Date().toISOString(), 1000); }
}
