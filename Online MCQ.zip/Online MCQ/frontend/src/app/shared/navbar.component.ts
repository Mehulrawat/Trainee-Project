import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="bar" *ngIf="auth.isLoggedIn()">
      <div class="left">
        <b>Online MCQ</b>
        <span class="pill">{{auth.userRole()}}</span>
      </div>
      <div class="links">
        <a *ngIf="auth.userRole()==='Student'" routerLink="/student">Student</a>
        <ng-container *ngIf="auth.userRole()==='Examiner' || auth.userRole()==='Admin'">
          <a routerLink="/examiner">Dashboard</a>
          <a routerLink="/examiner/questions">Questions</a>
          <a routerLink="/examiner/exams">Exams</a>
          <a routerLink="/examiner/reports">Reports</a>
        </ng-container>
        <a (click)="logout()" style="cursor:pointer">Logout</a>
      </div>
    </div>
  `,
  styles: [`
    .bar{display:flex;justify-content:space-between;align-items:center;padding:10px 16px;border:1px solid #ddd;border-radius:10px;margin:8px 0;}
    .links a{margin-left:12px;text-decoration:none;}
    .pill{margin-left:10px;padding:2px 10px;border:1px solid #ddd;border-radius:999px;font-size:12px;}
  `]
})
export class NavbarComponent {
  constructor(public auth: AuthService, private router: Router){}
  logout(){ this.auth.logout(); this.router.navigateByUrl('/login'); }
}
