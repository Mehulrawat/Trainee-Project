import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { WatermarkComponent } from './shared/watermark.component';
import { NavbarComponent } from './shared/navbar.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, WatermarkComponent, NavbarComponent],
  template: `
    <app-watermark></app-watermark>
    <app-navbar></app-navbar>
    <div style="padding:16px">
      <router-outlet></router-outlet>
    </div>
  `
})
export class AppComponent {}
