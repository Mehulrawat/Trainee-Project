import { Routes } from '@angular/router';
import { LoginComponent } from './views/login.component';
import { RegisterComponent } from './views/register.component';
import { StudentDashboardComponent } from './views/student-dashboard.component';
import { ExamRunnerComponent } from './views/exam-runner.component';
import { authGuard } from './services/auth.guard';
import { roleGuard } from './services/role.guard';
import { ExaminerDashboardComponent } from './views/examiner-dashboard.component';
import { ExaminerQuestionsComponent } from './views/examiner-questions.component';
import { ExaminerExamsComponent } from './views/examiner-exams.component';
import { ExaminerReportsComponent } from './views/examiner-reports.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'student' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'student', component: StudentDashboardComponent, canActivate: [authGuard] },
  { path: 'exam-runner/:attemptId', component: ExamRunnerComponent, canActivate: [authGuard] },
  { path: 'examiner', component: ExaminerDashboardComponent, canActivate: [roleGuard(['Examiner','Admin'])] },
  { path: 'examiner/questions', component: ExaminerQuestionsComponent, canActivate: [roleGuard(['Examiner','Admin'])] },
  { path: 'examiner/exams', component: ExaminerExamsComponent, canActivate: [roleGuard(['Examiner','Admin'])] },
  { path: 'examiner/reports', component: ExaminerReportsComponent, canActivate: [roleGuard(['Examiner','Admin'])] },
];
