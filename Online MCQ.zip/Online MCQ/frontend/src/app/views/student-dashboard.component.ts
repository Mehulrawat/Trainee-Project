import { Component } from '@angular/core';
import { StudentService } from '../services/student.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Student Dashboard</h2>
    <button (click)="logout()">Logout</button>
    <h3>Available Exams</h3>
    <button (click)="load()">Refresh</button>
    <ul>
      <li *ngFor="let e of exams">
        <b>{{e.title}}</b> ({{e.durationMinutes}} min)
        <button (click)="start(e.id)">Start</button>
      </li>
    </ul>
  `
})
export class StudentDashboardComponent {
  exams:any[]=[];
  constructor(private student: StudentService, private router: Router, private auth: AuthService){ this.load(); }
  async load(){ this.exams = await this.student.listExams(); }
  async start(examId: string){
    const res = await this.student.startExam(examId);
    this.router.navigateByUrl(`/exam-runner/${res.attemptId}`);
  }
  logout(){ this.auth.logout(); this.router.navigateByUrl('/login'); }
}
