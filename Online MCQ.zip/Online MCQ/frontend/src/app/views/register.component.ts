import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: `
    <h2>Register</h2>
    <div><label>Full name</label><br/><input [(ngModel)]="fullName"/></div>
    <div><label>Email</label><br/><input [(ngModel)]="email"/></div>
    <div><label>Password</label><br/><input [(ngModel)]="password" type="password"/></div>
    <div>
      <label>Role</label><br/>
      <select [(ngModel)]="role">
        <option>Student</option>
        <option>Examiner</option>
      </select>
    </div>
    <button (click)="register()">Register</button>
  `
})
export class RegisterComponent {
  fullName='New User';
  email='new@mcq.local';
  password='ChangeMyPa$$word1';
  role='Student';
  constructor(private api: ApiService, private auth: AuthService, private router: Router){}
  async register(){
    const res:any = await this.api.post('/api/auth/register', { email: this.email, password: this.password, fullName: this.fullName, role: this.role }).toPromise();
    this.auth.setToken(res.token);
    this.auth.setProfile({ email: res.email, fullName: res.fullName, role: res.role });
    this.router.navigateByUrl('/student');
  }
}
