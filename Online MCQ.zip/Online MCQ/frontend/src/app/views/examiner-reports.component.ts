import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ExaminerExamService } from '../services/examiner-exam.service';
import { ReportService } from '../services/report.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Reports</h2>

    <div class="card">
      <h3>Exam Summary</h3>
      <button (click)="loadExams()">Load exams</button>

      <div *ngIf="exams.length" style="margin-top:10px">
        <label>Select exam</label><br/>
        <select [(ngModel)]="selectedExamId">
          <option [ngValue]="''">(select)</option>
          <option *ngFor="let e of exams" [ngValue]="e.id">{{e.title}}</option>
        </select>
        <button (click)="fetch()">Fetch</button>
      </div>

      <pre *ngIf="report">{{report | json}}</pre>
    </div>
  `,
  styles: [`.card{border:1px solid #ddd;border-radius:12px;padding:12px;margin:12px 0;}`]
})
export class ExaminerReportsComponent {
  exams:any[]=[];
  selectedExamId='';
  report:any=null;

  constructor(private examsSvc: ExaminerExamService, private reports: ReportService){}
  async loadExams(){ this.exams = await this.examsSvc.list(); }
  async fetch(){
    this.report = null;
    if(!this.selectedExamId) return;
    this.report = await this.reports.examSummary(this.selectedExamId);
  }
}
