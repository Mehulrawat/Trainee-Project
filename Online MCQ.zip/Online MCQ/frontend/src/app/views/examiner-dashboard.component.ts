import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExaminerExamService } from '../services/examiner-exam.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Examiner/Admin Dashboard</h2>
    <p>Manage questions, exams, and reports from the menu above.</p>

    <h3>Recent Exams</h3>
    <button (click)="load()">Refresh</button>
    <ul>
      <li *ngFor="let e of exams">
        <b>{{e.title}}</b> — {{e.status}} — Duration: {{e.durationMinutes}} min
      </li>
    </ul>
  `
})
export class ExaminerDashboardComponent {
  exams:any[]=[];
  constructor(private examsSvc: ExaminerExamService){ this.load(); }
  async load(){ this.exams = await this.examsSvc.list(); }
}
