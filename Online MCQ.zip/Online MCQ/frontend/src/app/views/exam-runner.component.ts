import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from '../services/student.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Exam Runner</h2>

    <div *ngIf="!examActive">
      <p *ngIf="requireFullscreen">
        Fullscreen is required. Exiting fullscreen counts as a violation and may auto-submit.
      </p>
      <button (click)="startExam()">Enter fullscreen & Start</button>
    </div>

    <div *ngIf="examActive">
      <p><b>Status:</b> {{status}}</p>
      <p><b>Ends at (UTC):</b> {{endAtUtc}}</p>
      <p><b>Fullscreen exits:</b> {{fullscreenExitCount}} / {{fullscreenExitLimit}} ({{fullscreenViolationAction}})</p>
      <p *ngIf="isFlagged" style="color:#b00"><b>FLAGGED:</b> {{flagReason}}</p>
      <button (click)="submit()">Submit</button>
    </div>
  `
})
export class ExamRunnerComponent implements OnInit, OnDestroy {
  attemptId!: string;
  examActive = false;

  status = '';
  endAtUtc = '';

  requireFullscreen = true;
  fullscreenExitLimit = 1;
  fullscreenViolationAction = 'Flag';
  fullscreenExitCount = 0;

  isFlagged = false;
  flagReason = '';

  private fsHandler = () => this.onFullscreenChange();

  constructor(private route: ActivatedRoute, private student: StudentService){}

  async ngOnInit(){
    this.attemptId = this.route.snapshot.paramMap.get('attemptId')!;
    await this.refreshDetails();
    document.addEventListener('fullscreenchange', this.fsHandler);
  }

  ngOnDestroy(){
    document.removeEventListener('fullscreenchange', this.fsHandler);
  }

  async refreshDetails(){
    const d = await this.student.attemptDetails(this.attemptId);
    this.status = d.status;
    this.endAtUtc = d.endAtUtc;
    this.requireFullscreen = d.requireFullscreen;
    this.fullscreenExitLimit = d.fullscreenExitLimit;
    this.fullscreenViolationAction = d.fullscreenViolationAction;
    this.fullscreenExitCount = d.fullscreenExitCount;
    this.isFlagged = d.isFlagged;
    this.flagReason = d.flagReason || '';
  }

  async startExam(){
    if(this.requireFullscreen){
      const ok = await this.tryEnterFullscreen();
      if(!ok){
        await this.logViolation('FullscreenDenied');
        await this.refreshDetails();
        return;
      }
    }
    this.examActive = true;
  }

  async tryEnterFullscreen(): Promise<boolean>{
    try{
      await document.documentElement.requestFullscreen();
      return !!document.fullscreenElement;
    } catch { return false; }
  }

  async onFullscreenChange(){
    if(!this.examActive) return;
    if(this.requireFullscreen && !document.fullscreenElement){
      await this.logViolation('FullscreenExit');
      await this.refreshDetails();
      await this.tryEnterFullscreen();
    }
  }

  async logViolation(eventType: string){
    await this.student.logEvent(this.attemptId, { eventType, occurredAtUtc: new Date().toISOString(), metadataJson: null });
  }

  async submit(){
    await this.student.submit(this.attemptId);
    this.examActive = false;
    await this.refreshDetails();
  }
}
