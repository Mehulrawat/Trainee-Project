import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { QuestionService, CreateQuestionRequest } from '../services/question.service';
import { environment } from '../../environments/environment';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Question Bank</h2>

    <div class="card">
      <h3>Create Question</h3>

      <div>
        <label>Text</label><br/>
        <textarea [(ngModel)]="model.text" rows="3" style="width:100%"></textarea>
      </div>

      <div class="row">
        <div>
          <label>Type</label><br/>
          <select [(ngModel)]="model.type">
            <option [ngValue]="1">Single Correct</option>
            <option [ngValue]="2">Multi Correct</option>
          </select>
        </div>
        <div>
          <label>Marks</label><br/>
          <input type="number" [(ngModel)]="model.marks" />
        </div>
        <div>
          <label>Topic</label><br/>
          <input [(ngModel)]="model.topic" />
        </div>
        <div>
          <label>Difficulty</label><br/>
          <select [(ngModel)]="model.difficulty">
            <option value="">(none)</option>
            <option>Easy</option>
            <option>Medium</option>
            <option>Hard</option>
          </select>
        </div>
      </div>

      <div>
        <label>Tags (CSV)</label><br/>
        <input [(ngModel)]="model.tagsCsv" style="width:100%" />
      </div>

      <h4>Options</h4>
      <div *ngFor="let o of model.options; let i = index" class="opt">
        <input [(ngModel)]="o.text" placeholder="Option text" style="width:70%" />
        <label style="margin-left:10px">
          <input type="checkbox" [(ngModel)]="o.isCorrect" /> Correct
        </label>
        <button (click)="removeOpt(i)">Remove</button>
      </div>
      <button (click)="addOpt()">Add option</button>

      <div style="margin-top:10px">
        <button (click)="create()">Create</button>
        <span *ngIf="message" style="margin-left:10px">{{message}}</span>
      </div>
    </div>

    <div class="card">
      <h3>Bulk Import/Export (CSV)</h3>
      <p>Export: <a [href]="exportUrl" target="_blank">Download questions.csv</a></p>
      <p>Import: use Swagger or Postman to POST a file to <code>/api/questions/import/csv</code>.</p>
    </div>

    <div class="card">
      <h3>All Questions</h3>
      <button (click)="load()">Refresh</button>
      <div *ngFor="let q of questions" class="q">
        <b>{{q.text}}</b>
        <div class="meta">Type: {{q.type}} | Marks: {{q.marks}} | Topic: {{q.topic}} | Difficulty: {{q.difficulty}}</div>
        <ul>
          <li *ngFor="let o of q.options">
            {{o.text}} <span *ngIf="o.isCorrect">✅</span>
          </li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .card{border:1px solid #ddd;border-radius:12px;padding:12px;margin:12px 0;}
    .row{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;}
    .opt{display:flex;align-items:center;gap:10px;margin:6px 0;}
    .q{border-top:1px solid #eee;padding-top:10px;margin-top:10px;}
    .meta{font-size:12px;opacity:0.8;margin:4px 0;}
  `]
})
export class ExaminerQuestionsComponent {
  questions:any[]=[];
  message='';
  exportUrl = `${environment.apiBaseUrl}/api/questions/export/csv`;

  model: CreateQuestionRequest = {
    text: '',
    type: 1,
    marks: 1,
    topic: '',
    difficulty: '',
    tagsCsv: '',
    options: [
      { text: 'Option A', isCorrect: true },
      { text: 'Option B', isCorrect: false },
      { text: 'Option C', isCorrect: false },
      { text: 'Option D', isCorrect: false },
    ]
  };

  constructor(private qs: QuestionService){ this.load(); }
  async load(){ this.questions = await this.qs.list(); }
  addOpt(){ this.model.options.push({ text: '', isCorrect: false }); }
  removeOpt(i:number){ this.model.options.splice(i,1); }

  async create(){
    this.message = '';
    if(!this.model.text.trim()){ this.message = 'Text required'; return; }
    if(this.model.options.length < 2){ this.message = 'Need at least 2 options'; return; }
    const created = await this.qs.create(this.model);
    this.message = `Created`;
    await this.load();
  }
}
