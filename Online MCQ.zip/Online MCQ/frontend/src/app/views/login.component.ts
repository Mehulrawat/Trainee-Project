import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: `
    <h2>Login</h2>
    <div><label>Email</label><br/><input [(ngModel)]="email" /></div>
    <div><label>Password</label><br/><input [(ngModel)]="password" type="password" /></div>
    <button (click)="login()">Login</button>
    <p><a href="/register">Register</a></p>
  `
})
export class LoginComponent {
  email='student@mcq.local';
  password='ChangeMyPa$$word1';
  constructor(private api: ApiService, private auth: AuthService, private router: Router){}
  async login(){
    const res:any = await this.api.post('/api/auth/login', { email: this.email, password: this.password }).toPromise();
    this.auth.setToken(res.token);
    this.auth.setProfile({ email: res.email, fullName: res.fullName, role: res.role });
    this.router.navigateByUrl('/student');
  }
}
