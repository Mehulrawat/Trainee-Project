import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ExaminerExamService } from '../services/examiner-exam.service';
import { QuestionService } from '../services/question.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Exams</h2>

    <div class="card">
      <h3>Create Exam (basic)</h3>

      <div><label>Title</label><br/><input [(ngModel)]="title" style="width:100%"/></div>
      <div><label>Description</label><br/><textarea [(ngModel)]="description" rows="2" style="width:100%"></textarea></div>

      <div class="row">
        <div>
          <label>Start (UTC)</label><br/>
          <input [(ngModel)]="startAtUtc" style="width:100%"/>
        </div>
        <div>
          <label>End (UTC)</label><br/>
          <input [(ngModel)]="endAtUtc" style="width:100%"/>
        </div>
        <div>
          <label>Duration minutes</label><br/>
          <input type="number" [(ngModel)]="durationMinutes" />
        </div>
      </div>

      <h4>Proctoring (Fullscreen)</h4>
      <div class="row">
        <div>
          <label><input type="checkbox" [(ngModel)]="requireFullscreen"/> Require fullscreen</label>
        </div>
        <div>
          <label>Exit limit</label><br/>
          <input type="number" [(ngModel)]="fullscreenExitLimit" />
        </div>
        <div>
          <label>Action</label><br/>
          <select [(ngModel)]="fullscreenViolationAction">
            <option [ngValue]="1">Flag</option>
            <option [ngValue]="2">AutoSubmit</option>
          </select>
        </div>
      </div>

      <h4>Randomization</h4>
      <div class="row3">
        <label><input type="checkbox" [(ngModel)]="shuffleQuestions"/> Shuffle questions</label>
        <label><input type="checkbox" [(ngModel)]="shuffleOptions"/> Shuffle options</label>
        <label><input type="checkbox" [(ngModel)]="randomizePerStudent"/> Randomize per student</label>
      </div>

      <h4>Question selection (one section)</h4>
      <button (click)="loadQuestions()">Load questions</button>
      <div *ngIf="questions.length">
        <p>Select questions:</p>
        <div *ngFor="let q of questions">
          <label><input type="checkbox" [(ngModel)]="q._selected" /> {{q.text}}</label>
        </div>
      </div>

      <div style="margin-top:10px">
        <button (click)="create()">Create Draft</button>
        <span *ngIf="message" style="margin-left:10px">{{message}}</span>
      </div>
    </div>

    <div class="card">
      <h3>All Exams</h3>
      <button (click)="load()">Refresh</button>
      <ul>
        <li *ngFor="let e of exams">
          <b>{{e.title}}</b> — {{e.status}}
          <button (click)="publish(e.id)">Publish</button>
          <button (click)="close(e.id)">Close</button>
        </li>
      </ul>
    </div>
  `,
  styles: [`
    .card{border:1px solid #ddd;border-radius:12px;padding:12px;margin:12px 0;}
    .row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;align-items:center;}
    .row3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;align-items:center;}
  `]
})
export class ExaminerExamsComponent {
  exams:any[]=[];
  questions:any[]=[];
  message='';

  title='Sample Exam';
  description='Created from Examiner UI';
  startAtUtc=new Date().toISOString();
  endAtUtc=new Date(Date.now()+2*60*60*1000).toISOString();
  durationMinutes=30;

  randomizePerStudent=true;
  shuffleQuestions=true;
  shuffleOptions=true;

  requireFullscreen=true;
  fullscreenExitLimit=1;
  fullscreenViolationAction=1;

  constructor(private examsSvc: ExaminerExamService, private qs: QuestionService){ this.load(); }

  async load(){ this.exams = await this.examsSvc.list(); }
  async loadQuestions(){ this.questions = await this.qs.list(); }

  async create(){
    this.message='';
    const selectedIds = this.questions.filter(x=>x._selected).map(x=>x.id);
    if(selectedIds.length === 0){ this.message='Select at least one question'; return; }

    const payload = {
      title: this.title,
      description: this.description,
      startAtUtc: this.startAtUtc,
      endAtUtc: this.endAtUtc,
      durationMinutes: this.durationMinutes,
      randomizePerStudent: this.randomizePerStudent,
      shuffleQuestions: this.shuffleQuestions,
      shuffleOptions: this.shuffleOptions,
      randomTakeCount: null,
      enableNegativeMarking: false,
      negativeMarkPerWrong: 0,
      releaseResultsImmediately: false,
      resultsReleaseAtUtc: null,
      showCorrectAnswersAfterRelease: false,
      requireFullscreen: this.requireFullscreen,
      fullscreenExitLimit: this.fullscreenExitLimit,
      fullscreenViolationAction: this.fullscreenViolationAction,
      sections: [{ title: 'Section 1', order: 1, durationMinutes: null, questionIds: selectedIds }]
    };

    await this.examsSvc.create(payload);
    this.message='Created';
    await this.load();
  }

  async publish(id: string){ await this.examsSvc.publish(id); await this.load(); }
  async close(id: string){ await this.examsSvc.close(id); await this.load(); }
}
