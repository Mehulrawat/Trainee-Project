import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { firstValueFrom } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ReportService {
  constructor(private api: ApiService){}
  examSummary(examId: string){ return firstValueFrom(this.api.get<any>(`/api/reports/exam/${examId}`)); }
}
