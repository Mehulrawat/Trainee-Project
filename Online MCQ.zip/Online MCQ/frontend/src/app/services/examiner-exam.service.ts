import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { firstValueFrom } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ExaminerExamService {
  constructor(private api: ApiService){}
  list(){ return firstValueFrom(this.api.get<any[]>('/api/exams')); }
  create(payload: any){ return firstValueFrom(this.api.post<any>('/api/exams', payload)); }
  publish(examId: string){ return firstValueFrom(this.api.post<void>(`/api/exams/${examId}/publish`, {})); }
  close(examId: string){ return firstValueFrom(this.api.post<void>(`/api/exams/${examId}/close`, {})); }
}
