import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { firstValueFrom } from 'rxjs';

export type QuestionType = 1 | 2; // 1 SingleCorrect, 2 MultiCorrect
export interface OptionDto { text: string; isCorrect: boolean; }
export interface CreateQuestionRequest {
  text: string;
  type: QuestionType;
  marks: number;
  topic?: string | null;
  difficulty?: string | null;
  tagsCsv?: string | null;
  options: OptionDto[];
}

@Injectable({ providedIn: 'root' })
export class QuestionService {
  constructor(private api: ApiService){}
  list(){ return firstValueFrom(this.api.get<any[]>('/api/questions')); }
  create(payload: CreateQuestionRequest){ return firstValueFrom(this.api.post<any>('/api/questions', payload)); }
}
