import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

export const roleGuard = (roles: string[]): CanActivateFn => {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);
    const role = auth.userRole();
    if(!auth.isLoggedIn()){
      router.navigateByUrl('/login');
      return false;
    }
    if(!roles.includes(role)){
      if(role === 'Student') router.navigateByUrl('/student');
      else if(role === 'Examiner' || role === 'Admin') router.navigateByUrl('/examiner');
      else router.navigateByUrl('/login');
      return false;
    }
    return true;
  };
};
