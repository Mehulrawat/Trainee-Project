import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { firstValueFrom } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class StudentService {
  constructor(private api: ApiService){}
  listExams(){ return firstValueFrom(this.api.get<any[]>('/api/student/exams')); }
  startExam(examId: string){ return firstValueFrom(this.api.post<{attemptId:string}>(`/api/student/exams/${examId}/start`, {})); }
  attemptDetails(attemptId: string){ return firstValueFrom(this.api.get<any>(`/api/student/exams/attempts/${attemptId}`)); }
  submit(attemptId: string){ return firstValueFrom(this.api.post<void>(`/api/student/exams/attempts/${attemptId}/submit`, {})); }
  logEvent(attemptId: string, payload: any){ return firstValueFrom(this.api.post<void>(`/api/student/exams/attempts/${attemptId}/events`, payload)); }
}
