import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  setToken(t: string){ localStorage.setItem('token', t); }
  token(): string | null { return localStorage.getItem('token'); }
  isLoggedIn(): boolean { return !!this.token(); }

  setProfile(p: any){ localStorage.setItem('profile', JSON.stringify(p)); }
  profile(): any { try { return JSON.parse(localStorage.getItem('profile') || '{}'); } catch { return {}; } }

  userEmail(){ return this.profile().email || ''; }
  userFullName(){ return this.profile().fullName || ''; }
  userRole(){ return this.profile().role || ''; }

  logout(){ localStorage.clear(); }
}
