export const environment = { apiBaseUrl: 'https://localhost:5001' };
