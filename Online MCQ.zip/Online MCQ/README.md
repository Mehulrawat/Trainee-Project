# Online MCQ (BRD-complete baseline) — Backend + Frontend

## Includes
- ASP.NET Core 8 backend (SQL Server code-first, JWT + roles)
- Angular 20.3.8 frontend
- SMTP email notifications (publish + results)
- Question bank (single & multi-correct), CSV import/export
- Exams with sections, randomization, negative marking, result release policy
- Attempts with server auto-submit on timeout and fullscreen proctoring (auto-flag/auto-submit)

## Default logins (Password: ChangeMyPa$$word1)
- Admin: admin@mcq.local
- Examiner: examiner@mcq.local
- Student: student@mcq.local
