# Online MCQ – Backend (.NET 8)

## Run
```bash
cd backend
dotnet restore
dotnet run --project src/OnlineMcq.Api
```

## Swagger
Open `/swagger` on the running API.

## Seeded users (password: ChangeMyPa$$word1)
- Admin: admin@mcq.local
- Examiner: examiner@mcq.local
- Student: student@mcq.local

## Notes
- DB is code-first and initialized with `EnsureCreatedAsync()` for local/dev.
- Email notifications use SMTP (MailKit). Configure Smtp in appsettings.
