using OnlineMcq.Domain.Enums;
namespace OnlineMcq.Application.Contracts.Exams;
public record ExamSectionDto(string Title, int Order, int? DurationMinutes, List<Guid> QuestionIds);
public record CreateExamRequest(
    string Title,
    string? Description,
    DateTime StartAtUtc,
    DateTime EndAtUtc,
    int DurationMinutes,
    bool RandomizePerStudent,
    bool ShuffleQuestions,
    bool ShuffleOptions,
    int? RandomTakeCount,
    bool EnableNegativeMarking,
    decimal NegativeMarkPerWrong,
    bool ReleaseResultsImmediately,
    DateTime? ResultsReleaseAtUtc,
    bool ShowCorrectAnswersAfterRelease,
    bool RequireFullscreen,
    int FullscreenExitLimit,
    ViolationAction FullscreenViolationAction,
    List<ExamSectionDto> Sections
);
