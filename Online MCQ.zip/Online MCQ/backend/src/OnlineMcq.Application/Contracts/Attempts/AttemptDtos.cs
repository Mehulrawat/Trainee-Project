using OnlineMcq.Domain.Enums;
namespace OnlineMcq.Application.Contracts.Attempts;
public record StartAttemptResponse(Guid AttemptId);
public record SaveAnswerRequest(Guid QuestionId, List<Guid> SelectedOptionIds);
public record ProctorEventRequest(string EventType, DateTime OccurredAtUtc, string? MetadataJson);
public record AttemptDetailsResponse(
    Guid AttemptId,
    AttemptStatus Status,
    DateTime StartedAtUtc,
    DateTime EndAtUtc,
    bool RequireFullscreen,
    int FullscreenExitLimit,
    string FullscreenViolationAction,
    int FullscreenExitCount,
    bool IsFlagged,
    string? FlagReason,
    decimal Score,
    bool IsResultReleased,
    bool ShowCorrectAnswers
);
