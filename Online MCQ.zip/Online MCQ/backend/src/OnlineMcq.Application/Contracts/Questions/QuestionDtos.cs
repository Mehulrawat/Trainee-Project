using OnlineMcq.Domain.Enums;
namespace OnlineMcq.Application.Contracts.Questions;
public record OptionDto(string Text, bool IsCorrect);
public record CreateQuestionRequest(
    string Text,
    QuestionType Type,
    decimal Marks,
    string? Topic,
    string? Difficulty,
    string? TagsCsv,
    List<OptionDto> Options
);
