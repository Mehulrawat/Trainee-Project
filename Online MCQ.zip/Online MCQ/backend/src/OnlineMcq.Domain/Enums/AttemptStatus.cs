namespace OnlineMcq.Domain.Enums;
public enum AttemptStatus { InProgress = 1, Submitted = 2, AutoSubmitted = 3 }
