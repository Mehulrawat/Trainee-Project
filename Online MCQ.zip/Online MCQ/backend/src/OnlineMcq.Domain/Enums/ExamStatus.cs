namespace OnlineMcq.Domain.Enums;
public enum ExamStatus { Draft = 1, Published = 2, Closed = 3 }
