namespace OnlineMcq.Domain.Enums;
public enum QuestionType { SingleCorrect = 1, MultiCorrect = 2 }
