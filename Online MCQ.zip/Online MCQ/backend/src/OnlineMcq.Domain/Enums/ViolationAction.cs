namespace OnlineMcq.Domain.Enums;
public enum ViolationAction { Flag = 1, AutoSubmit = 2 }
