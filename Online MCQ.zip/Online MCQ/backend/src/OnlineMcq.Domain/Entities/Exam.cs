using OnlineMcq.Domain.Enums;
namespace OnlineMcq.Domain.Entities;

public class Exam
{
    public Guid Id { get; set; }
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public ExamStatus Status { get; set; } = ExamStatus.Draft;
    public DateTime StartAtUtc { get; set; }
    public DateTime EndAtUtc { get; set; }
    public int DurationMinutes { get; set; }

    // Randomization & pool
    public bool RandomizePerStudent { get; set; } = true;
    public bool ShuffleOptions { get; set; } = true;
    public bool ShuffleQuestions { get; set; } = true;
    public int? RandomTakeCount { get; set; }

    // Negative marking
    public bool EnableNegativeMarking { get; set; } = false;
    public decimal NegativeMarkPerWrong { get; set; } = 0;

    // Result visibility
    public bool ReleaseResultsImmediately { get; set; } = false;
    public DateTime? ResultsReleaseAtUtc { get; set; }
    public bool ShowCorrectAnswersAfterRelease { get; set; } = false;

    // Proctoring / fullscreen
    public bool RequireFullscreen { get; set; } = true;
    public int FullscreenExitLimit { get; set; } = 1;
    public ViolationAction FullscreenViolationAction { get; set; } = ViolationAction.Flag;

    public Guid CreatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    public ICollection<ExamSection> Sections { get; set; } = new List<ExamSection>();
}

public class ExamSection
{
    public Guid Id { get; set; }
    public Guid ExamId { get; set; }
    public string Title { get; set; } = "Section";
    public int Order { get; set; }
    public int? DurationMinutes { get; set; } // optional per-section timing
    public Exam Exam { get; set; } = default!;
    public ICollection<ExamSectionQuestion> Questions { get; set; } = new List<ExamSectionQuestion>();
}

public class ExamSectionQuestion
{
    public Guid Id { get; set; }
    public Guid ExamSectionId { get; set; }
    public Guid QuestionId { get; set; }
    public int Order { get; set; }
    public ExamSection ExamSection { get; set; } = default!;
    public Question Question { get; set; } = default!;
}
