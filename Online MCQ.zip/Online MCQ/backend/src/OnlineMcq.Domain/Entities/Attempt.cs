using OnlineMcq.Domain.Enums;
namespace OnlineMcq.Domain.Entities;

public class ExamAttempt
{
    public Guid Id { get; set; }
    public Guid ExamId { get; set; }
    public Guid StudentUserId { get; set; }
    public AttemptStatus Status { get; set; } = AttemptStatus.InProgress;

    public DateTime StartedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? SubmittedAtUtc { get; set; }

    // Locked paper
    public string LockedQuestionOrderCsv { get; set; } = "";
    public string LockedOptionOrdersJson { get; set; } = "{}";

    // Proctoring
    public int FullscreenExitCount { get; set; } = 0;
    public bool IsFlagged { get; set; } = false;
    public string? FlagReason { get; set; }
    public DateTime? FlaggedAtUtc { get; set; }

    // Results
    public decimal Score { get; set; } = 0;
    public bool IsResultReleased { get; set; } = false;

    public Exam Exam { get; set; } = default!;
    public ICollection<AttemptAnswer> Answers { get; set; } = new List<AttemptAnswer>();
    public ICollection<ProctoringEvent> ProctoringEvents { get; set; } = new List<ProctoringEvent>();
}

public class AttemptAnswer
{
    public Guid Id { get; set; }
    public Guid ExamAttemptId { get; set; }
    public Guid QuestionId { get; set; }
    public string SelectedOptionIdsCsv { get; set; } = "";
    public decimal AwardedMarks { get; set; } = 0;
    public ExamAttempt Attempt { get; set; } = default!;
}

public class ProctoringEvent
{
    public Guid Id { get; set; }
    public Guid ExamAttemptId { get; set; }
    public string EventType { get; set; } = "";
    public DateTime OccurredAtUtc { get; set; } = DateTime.UtcNow;
    public string? MetadataJson { get; set; }
    public ExamAttempt Attempt { get; set; } = default!;
}

public class EmailLog
{
    public Guid Id { get; set; }
    public string ToEmail { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Body { get; set; } = "";
    public DateTime SentAtUtc { get; set; } = DateTime.UtcNow;
    public bool Success { get; set; } = true;
    public string? Error { get; set; }
}

public class AuditLog
{
    public Guid Id { get; set; }
    public Guid? ActorUserId { get; set; }
    public string Action { get; set; } = "";
    public string Entity { get; set; } = "";
    public string EntityId { get; set; } = "";
    public DateTime AtUtc { get; set; } = DateTime.UtcNow;
    public string? DetailsJson { get; set; }
}
