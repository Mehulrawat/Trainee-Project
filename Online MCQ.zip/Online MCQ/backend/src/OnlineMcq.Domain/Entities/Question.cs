using OnlineMcq.Domain.Enums;
namespace OnlineMcq.Domain.Entities;

public class Question
{
    public Guid Id { get; set; }
    public string Text { get; set; } = "";
    public QuestionType Type { get; set; }
    public decimal Marks { get; set; } = 1;
    public string? Topic { get; set; }
    public string? Difficulty { get; set; } // Easy/Medium/Hard
    public string? TagsCsv { get; set; }
    public Guid CreatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public ICollection<QuestionOption> Options { get; set; } = new List<QuestionOption>();
}

public class QuestionOption
{
    public Guid Id { get; set; }
    public Guid QuestionId { get; set; }
    public string Text { get; set; } = "";
    public bool IsCorrect { get; set; }
    public Question Question { get; set; } = default!;
}
