using Microsoft.AspNetCore.Identity;
namespace OnlineMcq.Domain.Entities;
public class AppUser : IdentityUser<Guid> { public string FullName { get; set; } = ""; }
