using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Infrastructure.Persistence;

namespace OnlineMcq.Infrastructure.Email;

public interface IEmailSender { Task SendAsync(string toEmail, string subject, string body); }

public class EmailSender : IEmailSender
{
    private readonly SmtpOptions _opt;
    private readonly AppDbContext _db;
    public EmailSender(IOptions<SmtpOptions> opt, AppDbContext db) { _opt = opt.Value; _db = db; }

    public async Task SendAsync(string toEmail, string subject, string body)
    {
        var log = new EmailLog { Id = Guid.NewGuid(), ToEmail = toEmail, Subject = subject, Body = body, SentAtUtc = DateTime.UtcNow };

        try
        {
            var msg = new MimeMessage();
            msg.From.Add(new MailboxAddress(_opt.FromName, _opt.FromEmail));
            msg.To.Add(MailboxAddress.Parse(toEmail));
            msg.Subject = subject;
            msg.Body = new TextPart("plain") { Text = body };

            using var client = new SmtpClient();
            await client.ConnectAsync(_opt.Host, _opt.Port, _opt.UseStartTls);
            await client.AuthenticateAsync(_opt.Username, _opt.Password);
            await client.SendAsync(msg);
            await client.DisconnectAsync(true);

            log.Success = true;
        }
        catch (Exception ex)
        {
            log.Success = false;
            log.Error = ex.Message;
        }

        _db.EmailLogs.Add(log);
        await _db.SaveChangesAsync();
    }
}
