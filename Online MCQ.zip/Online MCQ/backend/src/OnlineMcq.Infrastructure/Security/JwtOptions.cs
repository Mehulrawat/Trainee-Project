namespace OnlineMcq.Infrastructure.Security;
public class JwtOptions
{
    public string Issuer { get; set; } = "OnlineMcq";
    public string Audience { get; set; } = "OnlineMcq";
    public string SigningKey { get; set; } = "CHANGE_ME_SUPER_LONG_SIGNING_KEY_32+";
    public int ExpMinutes { get; set; } = 120;
}
