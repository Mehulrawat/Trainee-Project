using Microsoft.EntityFrameworkCore;
using OnlineMcq.Infrastructure.Persistence;

namespace OnlineMcq.Api.Support;

public class ReportService
{
    private readonly AppDbContext _db;
    public ReportService(AppDbContext db) => _db = db;

    public async Task<object> ExamSummaryAsync(Guid examId)
    {
        var attempts = await _db.ExamAttempts.Where(a => a.ExamId == examId && a.Status != OnlineMcq.Domain.Enums.AttemptStatus.InProgress).ToListAsync();
        if (attempts.Count == 0) return new { examId, totalAttempts = 0, flaggedAttempts = 0, avgScore = 0, maxScore = 0, minScore = 0 };

        var scores = attempts.Select(a => a.Score).ToList();
        return new
        {
            examId,
            totalAttempts = attempts.Count,
            flaggedAttempts = attempts.Count(a => a.IsFlagged),
            avgScore = scores.Average(),
            maxScore = scores.Max(),
            minScore = scores.Min()
        };
    }
}
