using Microsoft.EntityFrameworkCore;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Domain.Enums;
using OnlineMcq.Infrastructure.Persistence;

namespace OnlineMcq.Api.Support;

public class AttemptService
{
    private readonly AppDbContext _db;
    public AttemptService(AppDbContext db) => _db = db;

    public DateTime GetAttemptEndUtc(ExamAttempt attempt) => attempt.StartedAtUtc.AddMinutes(attempt.Exam.DurationMinutes);

    public async Task SubmitAttemptAsync(Guid attemptId, bool systemTriggered)
    {
        var attempt = await _db.ExamAttempts.Include(a => a.Exam).FirstAsync(a => a.Id == attemptId);

        if (attempt.Status != AttemptStatus.InProgress) return;

        attempt.Status = systemTriggered ? AttemptStatus.AutoSubmitted : AttemptStatus.Submitted;
        attempt.SubmittedAtUtc = DateTime.UtcNow;

        var exam = attempt.Exam;
        var qIds = attempt.LockedQuestionOrderCsv.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(Guid.Parse).ToList();
        var questions = await _db.Questions.Include(q => q.Options).Where(q => qIds.Contains(q.Id)).ToListAsync();
        var answers = await _db.AttemptAnswers.Where(a => a.ExamAttemptId == attemptId).ToListAsync();

        decimal score = 0;
        foreach (var q in questions)
        {
            var ans = answers.FirstOrDefault(a => a.QuestionId == q.Id);
            var selected = (ans?.SelectedOptionIdsCsv ?? "")
                .Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(s => Guid.TryParse(s, out var g) ? g : Guid.Empty)
                .Where(g => g != Guid.Empty)
                .ToHashSet();

            var correct = q.Options.Where(o => o.IsCorrect).Select(o => o.Id).ToHashSet();
            decimal awarded = 0;

            if (q.Type == QuestionType.SingleCorrect)
            {
                awarded = selected.SetEquals(correct) ? q.Marks : 0;
                if (!selected.SetEquals(correct) && exam.EnableNegativeMarking && exam.NegativeMarkPerWrong > 0)
                    awarded -= exam.NegativeMarkPerWrong;
                if (awarded < 0) awarded = 0;
            }
            else
            {
                // Partial: +marks*(correctSelected/totalCorrect) - negative*wrongSelected
                var correctSelected = selected.Intersect(correct).Count();
                var wrongSelected = selected.Except(correct).Count();
                if (correct.Count > 0) awarded = q.Marks * (decimal)correctSelected / (decimal)correct.Count;
                if (exam.EnableNegativeMarking && exam.NegativeMarkPerWrong > 0 && wrongSelected > 0)
                    awarded -= exam.NegativeMarkPerWrong * wrongSelected;
                if (awarded < 0) awarded = 0;
            }

            if (ans != null) ans.AwardedMarks = awarded;
            score += awarded;
        }

        if (score < 0) score = 0;
        attempt.Score = score;

        attempt.IsResultReleased = exam.ReleaseResultsImmediately || (exam.ResultsReleaseAtUtc != null && DateTime.UtcNow >= exam.ResultsReleaseAtUtc);

        await _db.SaveChangesAsync();
    }
}
