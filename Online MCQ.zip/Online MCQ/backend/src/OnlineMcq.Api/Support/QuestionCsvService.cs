using System.Globalization;
using Microsoft.EntityFrameworkCore;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Domain.Enums;
using OnlineMcq.Infrastructure.Persistence;

namespace OnlineMcq.Api.Support;

public class QuestionCsvService
{
    private readonly AppDbContext _db;
    public QuestionCsvService(AppDbContext db) => _db = db;

    // CSV: Text,Type,Marks,Topic,Difficulty,Tags,Opt1,IsCorrect1,Opt2,IsCorrect2,...
    public async Task<int> ImportAsync(Stream csvStream, Guid createdByUserId)
    {
        using var reader = new StreamReader(csvStream);
        int count = 0;
        while (!reader.EndOfStream)
        {
            var line = await reader.ReadLineAsync();
            if (string.IsNullOrWhiteSpace(line)) continue;

            var parts = SplitCsvLine(line);
            if (parts.Count < 8 || parts[0].Equals("Text", StringComparison.OrdinalIgnoreCase)) continue;

            var text = parts[0];
            var type = Enum.TryParse<QuestionType>(parts[1], true, out var qt) ? qt : QuestionType.SingleCorrect;
            var marks = decimal.TryParse(parts[2], NumberStyles.Any, CultureInfo.InvariantCulture, out var m) ? m : 1;

            var q = new Question
            {
                Id = Guid.NewGuid(),
                Text = text,
                Type = type,
                Marks = marks,
                Topic = string.IsNullOrWhiteSpace(parts[3]) ? null : parts[3],
                Difficulty = string.IsNullOrWhiteSpace(parts[4]) ? null : parts[4],
                TagsCsv = string.IsNullOrWhiteSpace(parts[5]) ? null : parts[5],
                CreatedByUserId = createdByUserId,
                CreatedAtUtc = DateTime.UtcNow
            };

            for (int i = 6; i + 1 < parts.Count; i += 2)
            {
                var optText = parts[i];
                var isCorrect = bool.TryParse(parts[i + 1], out var b) && b;
                if (string.IsNullOrWhiteSpace(optText)) continue;
                q.Options.Add(new QuestionOption { Id = Guid.NewGuid(), QuestionId = q.Id, Text = optText, IsCorrect = isCorrect });
            }

            _db.Questions.Add(q);
            count++;
        }

        await _db.SaveChangesAsync();
        return count;
    }

    public async Task<string> ExportAsync()
    {
        var qs = await _db.Questions.Include(q => q.Options).OrderByDescending(q => q.CreatedAtUtc).ToListAsync();
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Text,Type,Marks,Topic,Difficulty,Tags,Option1,IsCorrect1,Option2,IsCorrect2,Option3,IsCorrect3,Option4,IsCorrect4");
        foreach (var q in qs)
        {
            var row = new List<string>
            {
                Esc(q.Text), q.Type.ToString(), q.Marks.ToString(CultureInfo.InvariantCulture),
                Esc(q.Topic ?? ""), Esc(q.Difficulty ?? ""), Esc(q.TagsCsv ?? "")
            };

            var opts = q.Options.Take(4).ToList();
            while (opts.Count < 4) opts.Add(new QuestionOption { Text = "", IsCorrect = false });

            foreach (var o in opts) { row.Add(Esc(o.Text)); row.Add(o.IsCorrect.ToString()); }
            sb.AppendLine(string.Join(",", row));
        }
        return sb.ToString();
    }

    private static string Esc(string s)
    {
        if (s.Contains(",") || s.Contains(""") || s.Contains("
")) return """ + s.Replace(""", """") + """;
        return s;
    }

    private static List<string> SplitCsvLine(string line)
    {
        var res = new List<string>();
        var cur = new System.Text.StringBuilder();
        bool inQuotes = false;
        for (int i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (c == '"')
            {
                if (inQuotes && i + 1 < line.Length && line[i + 1] == '"') { cur.Append('"'); i++; }
                else inQuotes = !inQuotes;
            }
            else if (c == ',' && !inQuotes) { res.Add(cur.ToString()); cur.Clear(); }
            else cur.Append(c);
        }
        res.Add(cur.ToString());
        return res;
    }
}
