using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Infrastructure.Persistence;

namespace OnlineMcq.Api.Support;

public static class SeedData
{
    public static async Task EnsureSeededAsync(WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        // Code-first: create schema automatically for local/dev
        await db.Database.EnsureCreatedAsync();

        var roleMgr = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        var userMgr = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>();

        foreach (var r in new[] { "Admin", "Examiner", "Student" })
        {
            if (!await roleMgr.RoleExistsAsync(r))
                await roleMgr.CreateAsync(new IdentityRole<Guid>(r));
        }

        async Task EnsureUser(string email, string fullName, string role)
        {
            var u = await userMgr.Users.FirstOrDefaultAsync(x => x.Email == email);
            if (u == null)
            {
                u = new AppUser { Id = Guid.NewGuid(), Email = email, UserName = email, FullName = fullName, EmailConfirmed = true };
                await userMgr.CreateAsync(u, "ChangeMyPa$$word1");
                await userMgr.AddToRoleAsync(u, role);
            }
        }

        await EnsureUser("admin@mcq.local", "Admin User", "Admin");
        await EnsureUser("examiner@mcq.local", "Examiner User", "Examiner");
        await EnsureUser("student@mcq.local", "Student User", "Student");
    }
}
