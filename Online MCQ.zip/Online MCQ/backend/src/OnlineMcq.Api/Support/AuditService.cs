using OnlineMcq.Domain.Entities;
using OnlineMcq.Infrastructure.Persistence;

namespace OnlineMcq.Api.Support;

public class AuditService
{
    private readonly AppDbContext _db;
    public AuditService(AppDbContext db) => _db = db;

    public async Task LogAsync(Guid? actorUserId, string action, string entity, string entityId, object? details = null)
    {
        _db.AuditLogs.Add(new AuditLog
        {
            Id = Guid.NewGuid(),
            ActorUserId = actorUserId,
            Action = action,
            Entity = entity,
            EntityId = entityId,
            DetailsJson = details is null ? null : System.Text.Json.JsonSerializer.Serialize(details),
            AtUtc = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }
}
