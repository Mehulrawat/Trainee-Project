using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineMcq.Application.Contracts.Questions;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Infrastructure.Persistence;
using OnlineMcq.Api.Support;
using System.Security.Claims;

namespace OnlineMcq.Api.Controllers;

[ApiController]
[Route("api/questions")]
[Authorize(Roles = "Admin,Examiner")]
public class QuestionsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AuditService _audit;
    private readonly QuestionCsvService _csv;

    public QuestionsController(AppDbContext db, AuditService audit, QuestionCsvService csv) { _db = db; _audit = audit; _csv = csv; }

    [HttpPost]
    public async Task<ActionResult<object>> Create(CreateQuestionRequest req)
    {
        var sub = User.FindFirst("sub")?.Value;
        var userId = Guid.TryParse(sub, out var g) ? g : Guid.Empty;

        var q = new Question
        {
            Id = Guid.NewGuid(),
            Text = req.Text,
            Type = req.Type,
            Marks = req.Marks,
            Topic = req.Topic,
            Difficulty = req.Difficulty,
            TagsCsv = req.TagsCsv,
            CreatedByUserId = userId
        };

        foreach (var o in req.Options)
            q.Options.Add(new QuestionOption { Id = Guid.NewGuid(), QuestionId = q.Id, Text = o.Text, IsCorrect = o.IsCorrect });

        _db.Questions.Add(q);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(userId, "CREATE", "Question", q.Id.ToString());
        return Ok(new { q.Id });
    }

    [HttpGet]
    public async Task<IActionResult> List()
    {
        var qs = await _db.Questions.Include(q => q.Options).OrderByDescending(q => q.CreatedAtUtc).ToListAsync();
        return Ok(qs);
    }

    [HttpPost("import/csv")]
    public async Task<IActionResult> ImportCsv(IFormFile file)
    {
        var sub = User.FindFirst("sub")?.Value;
        var userId = Guid.TryParse(sub, out var g) ? g : Guid.Empty;

        if (file.Length == 0) return BadRequest("Empty file");
        using var s = file.OpenReadStream();
        var imported = await _csv.ImportAsync(s, userId);
        await _audit.LogAsync(userId, "IMPORT_CSV", "Question", "-", new { imported });
        return Ok(new { imported });
    }

    [HttpGet("export/csv")]
    public async Task<IActionResult> ExportCsv()
    {
        var csv = await _csv.ExportAsync();
        return File(System.Text.Encoding.UTF8.GetBytes(csv), "text/csv", "questions.csv");
    }
}
