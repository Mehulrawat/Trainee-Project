using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OnlineMcq.Application.Contracts.Auth;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Infrastructure.Security;
using OnlineMcq.Api.Support;

namespace OnlineMcq.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly UserManager<AppUser> _users;
    private readonly SignInManager<AppUser> _signin;
    private readonly IJwtTokenService _jwt;
    private readonly AuditService _audit;

    public AuthController(UserManager<AppUser> users, SignInManager<AppUser> signin, IJwtTokenService jwt, AuditService audit)
    {
        _users = users;
        _signin = signin;
        _jwt = jwt;
        _audit = audit;
    }

    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest req)
    {
        var user = new AppUser { Id = Guid.NewGuid(), Email = req.Email, UserName = req.Email, FullName = req.FullName, EmailConfirmed = true };
        var res = await _users.CreateAsync(user, req.Password);
        if (!res.Succeeded) return BadRequest(new { errors = res.Errors.Select(e => e.Description) });

        await _users.AddToRoleAsync(user, req.Role);
        var token = _jwt.CreateToken(user, req.Role);
        await _audit.LogAsync(user.Id, "REGISTER", "User", user.Id.ToString(), new { req.Email, req.Role });

        return Ok(new AuthResponse(token, user.Email!, user.FullName, req.Role));
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest req)
    {
        var user = await _users.FindByEmailAsync(req.Email);
        if (user == null) return Unauthorized();

        var ok = await _signin.CheckPasswordSignInAsync(user, req.Password, lockoutOnFailure: false);
        if (!ok.Succeeded) return Unauthorized();

        var roles = await _users.GetRolesAsync(user);
        var role = roles.FirstOrDefault() ?? "Student";

        var token = _jwt.CreateToken(user, role);
        await _audit.LogAsync(user.Id, "LOGIN", "User", user.Id.ToString());

        return Ok(new AuthResponse(token, user.Email!, user.FullName, role));
    }
}
