using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineMcq.Api.Support;
using OnlineMcq.Application.Contracts.Attempts;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Domain.Enums;
using OnlineMcq.Infrastructure.Email;
using OnlineMcq.Infrastructure.Persistence;
using System.Security.Claims;
using System.Text.Json;

namespace OnlineMcq.Api.Controllers;

[ApiController]
[Route("api/student/exams")]
[Authorize(Roles = "Student")]
public class StudentExamsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AttemptService _attempts;
    private readonly UserManager<AppUser> _users;
    private readonly IEmailSender _email;

    public StudentExamsController(AppDbContext db, AttemptService attempts, UserManager<AppUser> users, IEmailSender email)
    {
        _db = db; _attempts = attempts; _users = users; _email = email;
    }

    [HttpGet]
    public async Task<IActionResult> ListAvailable()
    {
        var now = DateTime.UtcNow;
        var exams = await _db.Exams
            .Where(e => e.Status == ExamStatus.Published && e.StartAtUtc <= now && e.EndAtUtc >= now)
            .OrderBy(e => e.StartAtUtc)
            .Select(e => new { e.Id, e.Title, e.StartAtUtc, e.EndAtUtc, e.DurationMinutes })
            .ToListAsync();

        return Ok(exams);
    }

    [HttpPost("{examId:guid}/start")]
    public async Task<ActionResult<StartAttemptResponse>> Start(Guid examId)
    {
        var studentId = Guid.Parse(User.FindFirst("sub")!.Value);

        var exam = await _db.Exams
            .Include(e => e.Sections).ThenInclude(s => s.Questions)
            .FirstOrDefaultAsync(e => e.Id == examId);

        if (exam == null) return NotFound();
        if (exam.Status != ExamStatus.Published) return BadRequest("Exam not published");

        var existing = await _db.ExamAttempts.FirstOrDefaultAsync(a => a.ExamId == examId && a.StudentUserId == studentId && a.Status == AttemptStatus.InProgress);
        if (existing != null) return Ok(new StartAttemptResponse(existing.Id));

        var pool = exam.Sections.OrderBy(s => s.Order)
            .SelectMany(s => s.Questions.OrderBy(q => q.Order).Select(q => q.QuestionId))
            .Distinct()
            .ToList();

        if (pool.Count == 0) return BadRequest("No questions in exam.");

        var rng = new Random();
        var selected = pool.ToList();

        if (exam.RandomTakeCount is int take && take > 0 && take < selected.Count)
            selected = selected.OrderBy(_ => rng.Next()).Take(take).ToList();

        if (exam.ShuffleQuestions) selected = selected.OrderBy(_ => rng.Next()).ToList();

        var questions = await _db.Questions.Include(q => q.Options).Where(q => selected.Contains(q.Id)).ToListAsync();
        var optionOrders = new Dictionary<Guid, List<Guid>>();
        foreach (var q in questions)
        {
            var optIds = q.Options.Select(o => o.Id).ToList();
            if (exam.ShuffleOptions) optIds = optIds.OrderBy(_ => rng.Next()).ToList();
            optionOrders[q.Id] = optIds;
        }

        var attempt = new ExamAttempt
        {
            Id = Guid.NewGuid(),
            ExamId = exam.Id,
            StudentUserId = studentId,
            StartedAtUtc = DateTime.UtcNow,
            LockedQuestionOrderCsv = string.Join(",", selected),
            LockedOptionOrdersJson = JsonSerializer.Serialize(optionOrders),
        };

        _db.ExamAttempts.Add(attempt);
        await _db.SaveChangesAsync();

        return Ok(new StartAttemptResponse(attempt.Id));
    }

    [HttpGet("attempts/{attemptId:guid}")]
    public async Task<ActionResult<AttemptDetailsResponse>> GetAttempt(Guid attemptId)
    {
        var studentId = Guid.Parse(User.FindFirst("sub")!.Value);
        var attempt = await _db.ExamAttempts.Include(a => a.Exam).FirstOrDefaultAsync(a => a.Id == attemptId && a.StudentUserId == studentId);
        if (attempt == null) return NotFound();

        var end = _attempts.GetAttemptEndUtc(attempt);
        if (attempt.Status == AttemptStatus.InProgress && DateTime.UtcNow >= end)
            await _attempts.SubmitAttemptAsync(attempt.Id, systemTriggered: true);

        attempt = await _db.ExamAttempts.Include(a => a.Exam).FirstAsync(a => a.Id == attemptId);
        var exam = attempt.Exam;
        var showAnswers = attempt.IsResultReleased && exam.ShowCorrectAnswersAfterRelease;

        return Ok(new AttemptDetailsResponse(
            attempt.Id, attempt.Status, attempt.StartedAtUtc, end,
            exam.RequireFullscreen, exam.FullscreenExitLimit, exam.FullscreenViolationAction.ToString(),
            attempt.FullscreenExitCount, attempt.IsFlagged, attempt.FlagReason, attempt.Score,
            attempt.IsResultReleased, showAnswers
        ));
    }

    [HttpPost("attempts/{attemptId:guid}/answers")]
    public async Task<IActionResult> SaveAnswer(Guid attemptId, SaveAnswerRequest req)
    {
        var studentId = Guid.Parse(User.FindFirst("sub")!.Value);
        var attempt = await _db.ExamAttempts.FirstOrDefaultAsync(a => a.Id == attemptId && a.StudentUserId == studentId);
        if (attempt == null) return NotFound();
        if (attempt.Status != AttemptStatus.InProgress) return BadRequest("Attempt not in progress");

        var ans = await _db.AttemptAnswers.FirstOrDefaultAsync(a => a.ExamAttemptId == attemptId && a.QuestionId == req.QuestionId);
        if (ans == null)
        {
            ans = new AttemptAnswer { Id = Guid.NewGuid(), ExamAttemptId = attemptId, QuestionId = req.QuestionId };
            _db.AttemptAnswers.Add(ans);
        }
        ans.SelectedOptionIdsCsv = string.Join(",", req.SelectedOptionIds);

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpPost("attempts/{attemptId:guid}/submit")]
    public async Task<IActionResult> Submit(Guid attemptId)
    {
        var studentId = Guid.Parse(User.FindFirst("sub")!.Value);
        var attempt = await _db.ExamAttempts.Include(a => a.Exam).FirstOrDefaultAsync(a => a.Id == attemptId && a.StudentUserId == studentId);
        if (attempt == null) return NotFound();

        await _attempts.SubmitAttemptAsync(attemptId, systemTriggered: false);

        // Result email
        var student = await _users.FindByIdAsync(studentId.ToString());
        if (student?.Email != null)
            await _email.SendAsync(student.Email, $"Result: {attempt.Exam.Title}", $"Your exam score is: {attempt.Score}");

        return NoContent();
    }

    [HttpPost("attempts/{attemptId:guid}/events")]
    public async Task<IActionResult> LogEvent(Guid attemptId, ProctorEventRequest req)
    {
        var studentId = Guid.Parse(User.FindFirst("sub")!.Value);
        var attempt = await _db.ExamAttempts.Include(a => a.Exam).FirstOrDefaultAsync(a => a.Id == attemptId && a.StudentUserId == studentId);
        if (attempt == null) return NotFound();

        _db.ProctoringEvents.Add(new ProctoringEvent
        {
            Id = Guid.NewGuid(),
            ExamAttemptId = attemptId,
            EventType = req.EventType,
            OccurredAtUtc = req.OccurredAtUtc,
            MetadataJson = req.MetadataJson
        });

        if (req.EventType is "FullscreenExit" or "FullscreenDenied")
        {
            attempt.FullscreenExitCount++;
            if (attempt.Exam.RequireFullscreen && attempt.FullscreenExitCount >= attempt.Exam.FullscreenExitLimit)
            {
                if (attempt.Exam.FullscreenViolationAction == ViolationAction.AutoSubmit)
                {
                    await _db.SaveChangesAsync();
                    await _attempts.SubmitAttemptAsync(attemptId, systemTriggered: true);
                    return NoContent();
                }
                attempt.IsFlagged = true;
                attempt.FlaggedAtUtc = DateTime.UtcNow;
                attempt.FlagReason = $"Exceeded fullscreen exit limit ({attempt.FullscreenExitCount}/{attempt.Exam.FullscreenExitLimit}).";
            }
        }

        await _db.SaveChangesAsync();
        return NoContent();
    }
}
