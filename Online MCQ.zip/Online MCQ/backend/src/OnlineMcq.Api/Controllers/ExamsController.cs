using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineMcq.Api.Support;
using OnlineMcq.Application.Contracts.Exams;
using OnlineMcq.Domain.Entities;
using OnlineMcq.Domain.Enums;
using OnlineMcq.Infrastructure.Email;
using OnlineMcq.Infrastructure.Persistence;
using System.Security.Claims;

namespace OnlineMcq.Api.Controllers;

[ApiController]
[Route("api/exams")]
[Authorize(Roles = "Admin,Examiner")]
public class ExamsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AuditService _audit;
    private readonly UserManager<AppUser> _users;
    private readonly IEmailSender _email;

    public ExamsController(AppDbContext db, AuditService audit, UserManager<AppUser> users, IEmailSender email)
    {
        _db = db; _audit = audit; _users = users; _email = email;
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateExamRequest req)
    {
        var sub = User.FindFirst("sub")?.Value;
        var userId = Guid.TryParse(sub, out var g) ? g : Guid.Empty;

        var exam = new Exam
        {
            Id = Guid.NewGuid(),
            Title = req.Title,
            Description = req.Description,
            StartAtUtc = req.StartAtUtc,
            EndAtUtc = req.EndAtUtc,
            DurationMinutes = req.DurationMinutes,
            RandomizePerStudent = req.RandomizePerStudent,
            ShuffleQuestions = req.ShuffleQuestions,
            ShuffleOptions = req.ShuffleOptions,
            RandomTakeCount = req.RandomTakeCount,
            EnableNegativeMarking = req.EnableNegativeMarking,
            NegativeMarkPerWrong = req.NegativeMarkPerWrong,
            ReleaseResultsImmediately = req.ReleaseResultsImmediately,
            ResultsReleaseAtUtc = req.ResultsReleaseAtUtc,
            ShowCorrectAnswersAfterRelease = req.ShowCorrectAnswersAfterRelease,
            RequireFullscreen = req.RequireFullscreen,
            FullscreenExitLimit = req.FullscreenExitLimit,
            FullscreenViolationAction = req.FullscreenViolationAction,
            CreatedByUserId = userId,
            Status = ExamStatus.Draft
        };

        foreach (var s in req.Sections.OrderBy(x => x.Order))
        {
            var sec = new ExamSection { Id = Guid.NewGuid(), ExamId = exam.Id, Title = s.Title, Order = s.Order, DurationMinutes = s.DurationMinutes };
            int order = 1;
            foreach (var qid in s.QuestionIds)
                sec.Questions.Add(new ExamSectionQuestion { Id = Guid.NewGuid(), ExamSectionId = sec.Id, QuestionId = qid, Order = order++ });
            exam.Sections.Add(sec);
        }

        _db.Exams.Add(exam);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(userId, "CREATE", "Exam", exam.Id.ToString());

        return Ok(new { exam.Id });
    }

    [HttpGet]
    public async Task<IActionResult> List()
        => Ok(await _db.Exams.OrderByDescending(e => e.CreatedAtUtc).ToListAsync());

    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id)
    {
        var exam = await _db.Exams.FirstOrDefaultAsync(x => x.Id == id);
        if (exam == null) return NotFound();
        exam.Status = ExamStatus.Published;
        await _db.SaveChangesAsync();

        // Email all students (basic BRD notification)
        var students = await _users.GetUsersInRoleAsync("Student");
        foreach (var s in students.Where(x => !string.IsNullOrWhiteSpace(x.Email)))
            await _email.SendAsync(s.Email!, $"Exam Published: {exam.Title}", $"A new exam '{exam.Title}' is available.");

        return NoContent();
    }

    [HttpPost("{id:guid}/close")]
    public async Task<IActionResult> Close(Guid id)
    {
        var exam = await _db.Exams.FirstOrDefaultAsync(x => x.Id == id);
        if (exam == null) return NotFound();
        exam.Status = ExamStatus.Closed;
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
