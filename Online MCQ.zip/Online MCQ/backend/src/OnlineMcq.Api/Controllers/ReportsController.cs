using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineMcq.Api.Support;

namespace OnlineMcq.Api.Controllers;

[ApiController]
[Route("api/reports")]
[Authorize(Roles = "Admin,Examiner")]
public class ReportsController : ControllerBase
{
    private readonly ReportService _reports;
    public ReportsController(ReportService reports) => _reports = reports;

    [HttpGet("exam/{examId:guid}")]
    public async Task<IActionResult> Exam(Guid examId) => Ok(await _reports.ExamSummaryAsync(examId));
}
